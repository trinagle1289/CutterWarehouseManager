namespace HZH_Controls.Controls
{
	public enum MarkTextPositionStyle
	{
		Up = 1,
		Right = 2,
		Down = 4,
		Left = 8,
		Auto = 16
	}
}
