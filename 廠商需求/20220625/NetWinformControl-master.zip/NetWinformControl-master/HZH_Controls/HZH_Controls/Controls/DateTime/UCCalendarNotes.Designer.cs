﻿namespace HZH_Controls.Controls
{
    partial class UCCalendarNotes
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panTop = new System.Windows.Forms.Panel();
            this.lblMouth = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.btnMouthNext = new HZH_Controls.Controls.UCBtnExt();
            this.btnYearNext = new HZH_Controls.Controls.UCBtnExt();
            this.btbMouthLast = new HZH_Controls.Controls.UCBtnExt();
            this.btnYearLast = new HZH_Controls.Controls.UCBtnExt();
            this.panWeek = new System.Windows.Forms.TableLayoutPanel();
            this.lblWeek_7 = new System.Windows.Forms.Label();
            this.lblWeek_6 = new System.Windows.Forms.Label();
            this.lblWeek_5 = new System.Windows.Forms.Label();
            this.lblWeek_4 = new System.Windows.Forms.Label();
            this.lblWeek_3 = new System.Windows.Forms.Label();
            this.lblWeek_2 = new System.Windows.Forms.Label();
            this.lblWeek_1 = new System.Windows.Forms.Label();
            this.panDay = new System.Windows.Forms.TableLayoutPanel();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panSelectYear = new System.Windows.Forms.Panel();
            this.panSelectYearList = new System.Windows.Forms.TableLayoutPanel();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.lblYearNextList = new System.Windows.Forms.Label();
            this.lblYearLastList = new System.Windows.Forms.Label();
            this.panSelectMonth = new System.Windows.Forms.Panel();
            this.panSelectMonthList = new System.Windows.Forms.TableLayoutPanel();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.ucCalendarNotes_Week1 = new HZH_Controls.Controls.UCCalendarNotes_Week();
            this.ucSplitLine_H2 = new HZH_Controls.Controls.UCSplitLine_H();
            this.ucSplitLine_V4 = new HZH_Controls.Controls.UCSplitLine_V();
            this.ucSplitLine_V5 = new HZH_Controls.Controls.UCSplitLine_V();
            this.panTop.SuspendLayout();
            this.panWeek.SuspendLayout();
            this.panDay.SuspendLayout();
            this.panSelectYear.SuspendLayout();
            this.panSelectYearList.SuspendLayout();
            this.panSelectMonth.SuspendLayout();
            this.panSelectMonthList.SuspendLayout();
            this.SuspendLayout();
            // 
            // panTop
            // 
            this.panTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.panTop.Controls.Add(this.lblMouth);
            this.panTop.Controls.Add(this.lblYear);
            this.panTop.Controls.Add(this.btnMouthNext);
            this.panTop.Controls.Add(this.btnYearNext);
            this.panTop.Controls.Add(this.btbMouthLast);
            this.panTop.Controls.Add(this.btnYearLast);
            this.panTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panTop.Location = new System.Drawing.Point(1, 0);
            this.panTop.Name = "panTop";
            this.panTop.Size = new System.Drawing.Size(439, 38);
            this.panTop.TabIndex = 1;
            // 
            // lblMouth
            // 
            this.lblMouth.AutoSize = true;
            this.lblMouth.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.lblMouth.ForeColor = System.Drawing.Color.White;
            this.lblMouth.Location = new System.Drawing.Point(197, 9);
            this.lblMouth.Name = "lblMouth";
            this.lblMouth.Size = new System.Drawing.Size(47, 20);
            this.lblMouth.TabIndex = 2;
            this.lblMouth.Text = "-月 ▼";
            this.lblMouth.TextChanged += new System.EventHandler(this.lblMouth_TextChanged);
            this.lblMouth.Click += new System.EventHandler(this.lblMouth_Click);
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.lblYear.ForeColor = System.Drawing.Color.White;
            this.lblYear.Location = new System.Drawing.Point(42, 8);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(47, 20);
            this.lblYear.TabIndex = 2;
            this.lblYear.Text = "-年 ▼";
            this.lblYear.Click += new System.EventHandler(this.lblYear_Click);
            // 
            // btnMouthNext
            // 
            this.btnMouthNext.BackColor = System.Drawing.Color.Transparent;
            this.btnMouthNext.BtnBackColor = System.Drawing.Color.Transparent;
            this.btnMouthNext.BtnFont = new System.Drawing.Font("微软雅黑", 11F);
            this.btnMouthNext.BtnForeColor = System.Drawing.Color.White;
            this.btnMouthNext.BtnText = "▶";
            this.btnMouthNext.ConerRadius = 5;
            this.btnMouthNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMouthNext.EnabledMouseEffect = false;
            this.btnMouthNext.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.btnMouthNext.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnMouthNext.IsRadius = false;
            this.btnMouthNext.IsShowRect = false;
            this.btnMouthNext.IsShowTips = false;
            this.btnMouthNext.Location = new System.Drawing.Point(257, 4);
            this.btnMouthNext.Margin = new System.Windows.Forms.Padding(0);
            this.btnMouthNext.Name = "btnMouthNext";
            this.btnMouthNext.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.btnMouthNext.RectWidth = 1;
            this.btnMouthNext.Size = new System.Drawing.Size(20, 31);
            this.btnMouthNext.TabIndex = 1;
            this.btnMouthNext.TabStop = false;
            this.btnMouthNext.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.btnMouthNext.TipsText = "";
            // 
            // btnYearNext
            // 
            this.btnYearNext.BackColor = System.Drawing.Color.Transparent;
            this.btnYearNext.BtnBackColor = System.Drawing.Color.Transparent;
            this.btnYearNext.BtnFont = new System.Drawing.Font("微软雅黑", 11F);
            this.btnYearNext.BtnForeColor = System.Drawing.Color.White;
            this.btnYearNext.BtnText = "▶";
            this.btnYearNext.ConerRadius = 5;
            this.btnYearNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnYearNext.EnabledMouseEffect = false;
            this.btnYearNext.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.btnYearNext.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnYearNext.IsRadius = false;
            this.btnYearNext.IsShowRect = false;
            this.btnYearNext.IsShowTips = false;
            this.btnYearNext.Location = new System.Drawing.Point(115, 3);
            this.btnYearNext.Margin = new System.Windows.Forms.Padding(0);
            this.btnYearNext.Name = "btnYearNext";
            this.btnYearNext.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.btnYearNext.RectWidth = 1;
            this.btnYearNext.Size = new System.Drawing.Size(20, 31);
            this.btnYearNext.TabIndex = 1;
            this.btnYearNext.TabStop = false;
            this.btnYearNext.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.btnYearNext.TipsText = "";
            // 
            // btbMouthLast
            // 
            this.btbMouthLast.BackColor = System.Drawing.Color.Transparent;
            this.btbMouthLast.BtnBackColor = System.Drawing.Color.Transparent;
            this.btbMouthLast.BtnFont = new System.Drawing.Font("微软雅黑", 11F);
            this.btbMouthLast.BtnForeColor = System.Drawing.Color.White;
            this.btbMouthLast.BtnText = "◀";
            this.btbMouthLast.ConerRadius = 5;
            this.btbMouthLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btbMouthLast.EnabledMouseEffect = false;
            this.btbMouthLast.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.btbMouthLast.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btbMouthLast.IsRadius = false;
            this.btbMouthLast.IsShowRect = false;
            this.btbMouthLast.IsShowTips = false;
            this.btbMouthLast.Location = new System.Drawing.Point(174, 4);
            this.btbMouthLast.Margin = new System.Windows.Forms.Padding(0);
            this.btbMouthLast.Name = "btbMouthLast";
            this.btbMouthLast.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.btbMouthLast.RectWidth = 1;
            this.btbMouthLast.Size = new System.Drawing.Size(20, 31);
            this.btbMouthLast.TabIndex = 0;
            this.btbMouthLast.TabStop = false;
            this.btbMouthLast.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.btbMouthLast.TipsText = "";
            // 
            // btnYearLast
            // 
            this.btnYearLast.BackColor = System.Drawing.Color.Transparent;
            this.btnYearLast.BtnBackColor = System.Drawing.Color.Transparent;
            this.btnYearLast.BtnFont = new System.Drawing.Font("微软雅黑", 11F);
            this.btnYearLast.BtnForeColor = System.Drawing.Color.White;
            this.btnYearLast.BtnText = "◀";
            this.btnYearLast.ConerRadius = 5;
            this.btnYearLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnYearLast.EnabledMouseEffect = false;
            this.btnYearLast.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.btnYearLast.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnYearLast.IsRadius = false;
            this.btnYearLast.IsShowRect = false;
            this.btnYearLast.IsShowTips = false;
            this.btnYearLast.Location = new System.Drawing.Point(22, 3);
            this.btnYearLast.Margin = new System.Windows.Forms.Padding(0);
            this.btnYearLast.Name = "btnYearLast";
            this.btnYearLast.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(58)))));
            this.btnYearLast.RectWidth = 1;
            this.btnYearLast.Size = new System.Drawing.Size(20, 31);
            this.btnYearLast.TabIndex = 0;
            this.btnYearLast.TabStop = false;
            this.btnYearLast.TipsColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(30)))), ((int)(((byte)(99)))));
            this.btnYearLast.TipsText = "";
            // 
            // panWeek
            // 
            this.panWeek.ColumnCount = 7;
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panWeek.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panWeek.Controls.Add(this.lblWeek_7, 6, 0);
            this.panWeek.Controls.Add(this.lblWeek_6, 5, 0);
            this.panWeek.Controls.Add(this.lblWeek_5, 4, 0);
            this.panWeek.Controls.Add(this.lblWeek_4, 3, 0);
            this.panWeek.Controls.Add(this.lblWeek_3, 2, 0);
            this.panWeek.Controls.Add(this.lblWeek_2, 1, 0);
            this.panWeek.Controls.Add(this.lblWeek_1, 0, 0);
            this.panWeek.Dock = System.Windows.Forms.DockStyle.Top;
            this.panWeek.Location = new System.Drawing.Point(1, 38);
            this.panWeek.Name = "panWeek";
            this.panWeek.RowCount = 1;
            this.panWeek.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.panWeek.Size = new System.Drawing.Size(439, 23);
            this.panWeek.TabIndex = 2;
            // 
            // lblWeek_7
            // 
            this.lblWeek_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_7.Location = new System.Drawing.Point(375, 0);
            this.lblWeek_7.Name = "lblWeek_7";
            this.lblWeek_7.Size = new System.Drawing.Size(61, 23);
            this.lblWeek_7.TabIndex = 6;
            this.lblWeek_7.Text = "六";
            this.lblWeek_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWeek_6
            // 
            this.lblWeek_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_6.Location = new System.Drawing.Point(313, 0);
            this.lblWeek_6.Name = "lblWeek_6";
            this.lblWeek_6.Size = new System.Drawing.Size(56, 23);
            this.lblWeek_6.TabIndex = 5;
            this.lblWeek_6.Text = "五";
            this.lblWeek_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWeek_5
            // 
            this.lblWeek_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_5.Location = new System.Drawing.Point(251, 0);
            this.lblWeek_5.Name = "lblWeek_5";
            this.lblWeek_5.Size = new System.Drawing.Size(56, 23);
            this.lblWeek_5.TabIndex = 4;
            this.lblWeek_5.Text = "四";
            this.lblWeek_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWeek_4
            // 
            this.lblWeek_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_4.Location = new System.Drawing.Point(189, 0);
            this.lblWeek_4.Name = "lblWeek_4";
            this.lblWeek_4.Size = new System.Drawing.Size(56, 23);
            this.lblWeek_4.TabIndex = 3;
            this.lblWeek_4.Text = "三";
            this.lblWeek_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWeek_3
            // 
            this.lblWeek_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_3.Location = new System.Drawing.Point(127, 0);
            this.lblWeek_3.Name = "lblWeek_3";
            this.lblWeek_3.Size = new System.Drawing.Size(56, 23);
            this.lblWeek_3.TabIndex = 2;
            this.lblWeek_3.Text = "二";
            this.lblWeek_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWeek_2
            // 
            this.lblWeek_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_2.Location = new System.Drawing.Point(65, 0);
            this.lblWeek_2.Name = "lblWeek_2";
            this.lblWeek_2.Size = new System.Drawing.Size(56, 23);
            this.lblWeek_2.TabIndex = 1;
            this.lblWeek_2.Text = "一";
            this.lblWeek_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWeek_1
            // 
            this.lblWeek_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWeek_1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWeek_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.lblWeek_1.Location = new System.Drawing.Point(3, 0);
            this.lblWeek_1.Name = "lblWeek_1";
            this.lblWeek_1.Size = new System.Drawing.Size(56, 23);
            this.lblWeek_1.TabIndex = 0;
            this.lblWeek_1.Text = "日";
            this.lblWeek_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panDay
            // 
            this.panDay.ColumnCount = 7;
            this.panDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panDay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panDay.Controls.Add(this.label42, 6, 5);
            this.panDay.Controls.Add(this.label41, 5, 5);
            this.panDay.Controls.Add(this.label40, 4, 5);
            this.panDay.Controls.Add(this.label39, 3, 5);
            this.panDay.Controls.Add(this.label38, 2, 5);
            this.panDay.Controls.Add(this.label37, 1, 5);
            this.panDay.Controls.Add(this.label36, 0, 5);
            this.panDay.Controls.Add(this.label35, 6, 4);
            this.panDay.Controls.Add(this.label34, 5, 4);
            this.panDay.Controls.Add(this.label33, 4, 4);
            this.panDay.Controls.Add(this.label32, 3, 4);
            this.panDay.Controls.Add(this.label31, 2, 4);
            this.panDay.Controls.Add(this.label30, 1, 4);
            this.panDay.Controls.Add(this.label29, 0, 4);
            this.panDay.Controls.Add(this.label28, 6, 3);
            this.panDay.Controls.Add(this.label27, 5, 3);
            this.panDay.Controls.Add(this.label26, 4, 3);
            this.panDay.Controls.Add(this.label25, 3, 3);
            this.panDay.Controls.Add(this.label24, 2, 3);
            this.panDay.Controls.Add(this.label23, 1, 3);
            this.panDay.Controls.Add(this.label22, 0, 3);
            this.panDay.Controls.Add(this.label21, 6, 2);
            this.panDay.Controls.Add(this.label20, 5, 2);
            this.panDay.Controls.Add(this.label19, 4, 2);
            this.panDay.Controls.Add(this.label18, 3, 2);
            this.panDay.Controls.Add(this.label17, 2, 2);
            this.panDay.Controls.Add(this.label16, 1, 2);
            this.panDay.Controls.Add(this.label15, 0, 2);
            this.panDay.Controls.Add(this.label14, 6, 1);
            this.panDay.Controls.Add(this.label13, 5, 1);
            this.panDay.Controls.Add(this.label12, 4, 1);
            this.panDay.Controls.Add(this.label11, 3, 1);
            this.panDay.Controls.Add(this.label10, 2, 1);
            this.panDay.Controls.Add(this.label9, 1, 1);
            this.panDay.Controls.Add(this.label8, 0, 1);
            this.panDay.Controls.Add(this.label7, 6, 0);
            this.panDay.Controls.Add(this.label6, 5, 0);
            this.panDay.Controls.Add(this.label5, 4, 0);
            this.panDay.Controls.Add(this.label4, 3, 0);
            this.panDay.Controls.Add(this.label3, 2, 0);
            this.panDay.Controls.Add(this.label2, 1, 0);
            this.panDay.Controls.Add(this.label1, 0, 0);
            this.panDay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panDay.Location = new System.Drawing.Point(1, 61);
            this.panDay.Name = "panDay";
            this.panDay.RowCount = 6;
            this.panDay.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panDay.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panDay.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panDay.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panDay.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panDay.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panDay.Size = new System.Drawing.Size(439, 284);
            this.panDay.TabIndex = 5;
            // 
            // label42
            // 
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label42.Location = new System.Drawing.Point(375, 235);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(61, 49);
            this.label42.TabIndex = 42;
            this.label42.Text = "-";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label41.Location = new System.Drawing.Point(313, 235);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(56, 49);
            this.label41.TabIndex = 41;
            this.label41.Text = "-";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label40.Location = new System.Drawing.Point(251, 235);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(56, 49);
            this.label40.TabIndex = 40;
            this.label40.Text = "-";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label39.Location = new System.Drawing.Point(189, 235);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(56, 49);
            this.label39.TabIndex = 39;
            this.label39.Text = "-";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label38.Location = new System.Drawing.Point(127, 235);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(56, 49);
            this.label38.TabIndex = 38;
            this.label38.Text = "-";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label37.Location = new System.Drawing.Point(65, 235);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(56, 49);
            this.label37.TabIndex = 37;
            this.label37.Text = "-";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label36.Location = new System.Drawing.Point(3, 235);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(56, 49);
            this.label36.TabIndex = 36;
            this.label36.Text = "-";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label35.Location = new System.Drawing.Point(375, 188);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(61, 47);
            this.label35.TabIndex = 35;
            this.label35.Text = "-";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label34.Location = new System.Drawing.Point(313, 188);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(56, 47);
            this.label34.TabIndex = 34;
            this.label34.Text = "-";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label33.Location = new System.Drawing.Point(251, 188);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(56, 47);
            this.label33.TabIndex = 33;
            this.label33.Text = "-";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label32.Location = new System.Drawing.Point(189, 188);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(56, 47);
            this.label32.TabIndex = 32;
            this.label32.Text = "-";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label31.Location = new System.Drawing.Point(127, 188);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(56, 47);
            this.label31.TabIndex = 31;
            this.label31.Text = "-";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label30.Location = new System.Drawing.Point(65, 188);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(56, 47);
            this.label30.TabIndex = 30;
            this.label30.Text = "-";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label29.Location = new System.Drawing.Point(3, 188);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(56, 47);
            this.label29.TabIndex = 29;
            this.label29.Text = "-";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label28.Location = new System.Drawing.Point(375, 141);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(61, 47);
            this.label28.TabIndex = 28;
            this.label28.Text = "-";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label27.Location = new System.Drawing.Point(313, 141);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(56, 47);
            this.label27.TabIndex = 27;
            this.label27.Text = "-";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label26.Location = new System.Drawing.Point(251, 141);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(56, 47);
            this.label26.TabIndex = 26;
            this.label26.Text = "-";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label25.Location = new System.Drawing.Point(189, 141);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(56, 47);
            this.label25.TabIndex = 25;
            this.label25.Text = "-";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label24.Location = new System.Drawing.Point(127, 141);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(56, 47);
            this.label24.TabIndex = 24;
            this.label24.Text = "-";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label23.Location = new System.Drawing.Point(65, 141);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(56, 47);
            this.label23.TabIndex = 23;
            this.label23.Text = "-";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label22.Location = new System.Drawing.Point(3, 141);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(56, 47);
            this.label22.TabIndex = 22;
            this.label22.Text = "-";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label21.Location = new System.Drawing.Point(375, 94);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(61, 47);
            this.label21.TabIndex = 21;
            this.label21.Text = "-";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label20.Location = new System.Drawing.Point(313, 94);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 47);
            this.label20.TabIndex = 20;
            this.label20.Text = "-";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label19.Location = new System.Drawing.Point(251, 94);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(56, 47);
            this.label19.TabIndex = 19;
            this.label19.Text = "-";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label18.Location = new System.Drawing.Point(189, 94);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 47);
            this.label18.TabIndex = 18;
            this.label18.Text = "-";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label17.Location = new System.Drawing.Point(127, 94);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 47);
            this.label17.TabIndex = 17;
            this.label17.Text = "-";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label16.Location = new System.Drawing.Point(65, 94);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 47);
            this.label16.TabIndex = 16;
            this.label16.Text = "-";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label15.Location = new System.Drawing.Point(3, 94);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 47);
            this.label15.TabIndex = 15;
            this.label15.Text = "-";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label14.Location = new System.Drawing.Point(375, 47);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 47);
            this.label14.TabIndex = 14;
            this.label14.Text = "-";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label13.Location = new System.Drawing.Point(313, 47);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 47);
            this.label13.TabIndex = 13;
            this.label13.Text = "-";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label12.Location = new System.Drawing.Point(251, 47);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 47);
            this.label12.TabIndex = 12;
            this.label12.Text = "-";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label11.Location = new System.Drawing.Point(189, 47);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 47);
            this.label11.TabIndex = 11;
            this.label11.Text = "-";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label10.Location = new System.Drawing.Point(127, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 47);
            this.label10.TabIndex = 10;
            this.label10.Text = "-";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label9.Location = new System.Drawing.Point(65, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 47);
            this.label9.TabIndex = 9;
            this.label9.Text = "-";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label8.Location = new System.Drawing.Point(3, 47);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 47);
            this.label8.TabIndex = 8;
            this.label8.Text = "-";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label7.Location = new System.Drawing.Point(375, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 47);
            this.label7.TabIndex = 7;
            this.label7.Text = "-";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label6.Location = new System.Drawing.Point(313, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 47);
            this.label6.TabIndex = 6;
            this.label6.Text = "-";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label5.Location = new System.Drawing.Point(251, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 47);
            this.label5.TabIndex = 5;
            this.label5.Text = "-";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label4.Location = new System.Drawing.Point(189, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 47);
            this.label4.TabIndex = 4;
            this.label4.Text = "-";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label3.Location = new System.Drawing.Point(127, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 47);
            this.label3.TabIndex = 3;
            this.label3.Text = "-";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label2.Location = new System.Drawing.Point(65, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 47);
            this.label2.TabIndex = 2;
            this.label2.Text = "-";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 47);
            this.label1.TabIndex = 1;
            this.label1.Text = "-";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panSelectYear
            // 
            this.panSelectYear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.panSelectYear.Controls.Add(this.panSelectYearList);
            this.panSelectYear.Controls.Add(this.lblYearNextList);
            this.panSelectYear.Controls.Add(this.lblYearLastList);
            this.panSelectYear.Location = new System.Drawing.Point(7, 40);
            this.panSelectYear.Name = "panSelectYear";
            this.panSelectYear.Size = new System.Drawing.Size(128, 239);
            this.panSelectYear.TabIndex = 6;
            this.panSelectYear.Visible = false;
            this.panSelectYear.VisibleChanged += new System.EventHandler(this.panSelectYear_VisibleChanged);
            // 
            // panSelectYearList
            // 
            this.panSelectYearList.ColumnCount = 2;
            this.panSelectYearList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panSelectYearList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panSelectYearList.Controls.Add(this.label71, 1, 6);
            this.panSelectYearList.Controls.Add(this.label72, 0, 6);
            this.panSelectYearList.Controls.Add(this.label69, 1, 5);
            this.panSelectYearList.Controls.Add(this.label70, 0, 5);
            this.panSelectYearList.Controls.Add(this.label67, 1, 4);
            this.panSelectYearList.Controls.Add(this.label68, 0, 4);
            this.panSelectYearList.Controls.Add(this.label66, 1, 3);
            this.panSelectYearList.Controls.Add(this.label65, 0, 3);
            this.panSelectYearList.Controls.Add(this.label63, 1, 2);
            this.panSelectYearList.Controls.Add(this.label64, 0, 2);
            this.panSelectYearList.Controls.Add(this.label61, 0, 1);
            this.panSelectYearList.Controls.Add(this.label62, 0, 1);
            this.panSelectYearList.Controls.Add(this.label60, 1, 0);
            this.panSelectYearList.Controls.Add(this.label59, 0, 0);
            this.panSelectYearList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSelectYearList.Location = new System.Drawing.Point(0, 24);
            this.panSelectYearList.Name = "panSelectYearList";
            this.panSelectYearList.RowCount = 7;
            this.panSelectYearList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panSelectYearList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panSelectYearList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panSelectYearList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panSelectYearList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panSelectYearList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panSelectYearList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.panSelectYearList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.panSelectYearList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.panSelectYearList.Size = new System.Drawing.Size(128, 191);
            this.panSelectYearList.TabIndex = 3;
            // 
            // label71
            // 
            this.label71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label71.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label71.ForeColor = System.Drawing.Color.White;
            this.label71.Location = new System.Drawing.Point(67, 162);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(58, 29);
            this.label71.TabIndex = 13;
            this.label71.Tag = "";
            this.label71.Text = "-";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label72.ForeColor = System.Drawing.Color.White;
            this.label72.Location = new System.Drawing.Point(3, 162);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(58, 29);
            this.label72.TabIndex = 14;
            this.label72.Tag = "";
            this.label72.Text = "-";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label69.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label69.ForeColor = System.Drawing.Color.White;
            this.label69.Location = new System.Drawing.Point(67, 135);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(58, 27);
            this.label69.TabIndex = 11;
            this.label69.Tag = "";
            this.label69.Text = "-";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label70
            // 
            this.label70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label70.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label70.ForeColor = System.Drawing.Color.White;
            this.label70.Location = new System.Drawing.Point(3, 135);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(58, 27);
            this.label70.TabIndex = 12;
            this.label70.Tag = "";
            this.label70.Text = "-";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label67.ForeColor = System.Drawing.Color.White;
            this.label67.Location = new System.Drawing.Point(67, 108);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(58, 27);
            this.label67.TabIndex = 9;
            this.label67.Tag = "";
            this.label67.Text = "-";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label68.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label68.ForeColor = System.Drawing.Color.White;
            this.label68.Location = new System.Drawing.Point(3, 108);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(58, 27);
            this.label68.TabIndex = 10;
            this.label68.Tag = "";
            this.label68.Text = "-";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label66.ForeColor = System.Drawing.Color.White;
            this.label66.Location = new System.Drawing.Point(67, 81);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(58, 27);
            this.label66.TabIndex = 8;
            this.label66.Tag = "";
            this.label66.Text = "-";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label65.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label65.ForeColor = System.Drawing.Color.White;
            this.label65.Location = new System.Drawing.Point(3, 81);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(58, 27);
            this.label65.TabIndex = 7;
            this.label65.Tag = "";
            this.label65.Text = "-";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label63.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label63.ForeColor = System.Drawing.Color.White;
            this.label63.Location = new System.Drawing.Point(67, 54);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(58, 27);
            this.label63.TabIndex = 5;
            this.label63.Tag = "";
            this.label63.Text = "-";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label64.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label64.ForeColor = System.Drawing.Color.White;
            this.label64.Location = new System.Drawing.Point(3, 54);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(58, 27);
            this.label64.TabIndex = 6;
            this.label64.Tag = "";
            this.label64.Text = "-";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label61.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label61.ForeColor = System.Drawing.Color.White;
            this.label61.Location = new System.Drawing.Point(3, 27);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(58, 27);
            this.label61.TabIndex = 3;
            this.label61.Tag = "";
            this.label61.Text = "-";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label62.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label62.ForeColor = System.Drawing.Color.White;
            this.label62.Location = new System.Drawing.Point(67, 27);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(58, 27);
            this.label62.TabIndex = 4;
            this.label62.Tag = "";
            this.label62.Text = "-";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label60.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label60.ForeColor = System.Drawing.Color.White;
            this.label60.Location = new System.Drawing.Point(67, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(58, 27);
            this.label60.TabIndex = 2;
            this.label60.Tag = "";
            this.label60.Text = "-";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label59.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label59.ForeColor = System.Drawing.Color.White;
            this.label59.Location = new System.Drawing.Point(3, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(58, 27);
            this.label59.TabIndex = 1;
            this.label59.Tag = "";
            this.label59.Text = "-";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblYearNextList
            // 
            this.lblYearNextList.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblYearNextList.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.lblYearNextList.ForeColor = System.Drawing.Color.White;
            this.lblYearNextList.Location = new System.Drawing.Point(0, 215);
            this.lblYearNextList.Name = "lblYearNextList";
            this.lblYearNextList.Size = new System.Drawing.Size(128, 24);
            this.lblYearNextList.TabIndex = 2;
            this.lblYearNextList.Tag = "";
            this.lblYearNextList.Text = "▼";
            this.lblYearNextList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblYearLastList
            // 
            this.lblYearLastList.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblYearLastList.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.lblYearLastList.ForeColor = System.Drawing.Color.White;
            this.lblYearLastList.Location = new System.Drawing.Point(0, 0);
            this.lblYearLastList.Name = "lblYearLastList";
            this.lblYearLastList.Size = new System.Drawing.Size(128, 24);
            this.lblYearLastList.TabIndex = 1;
            this.lblYearLastList.Tag = "";
            this.lblYearLastList.Text = "▲";
            this.lblYearLastList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panSelectMonth
            // 
            this.panSelectMonth.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.panSelectMonth.Controls.Add(this.panSelectMonthList);
            this.panSelectMonth.Location = new System.Drawing.Point(165, 41);
            this.panSelectMonth.Name = "panSelectMonth";
            this.panSelectMonth.Size = new System.Drawing.Size(128, 239);
            this.panSelectMonth.TabIndex = 7;
            this.panSelectMonth.Visible = false;
            // 
            // panSelectMonthList
            // 
            this.panSelectMonthList.ColumnCount = 2;
            this.panSelectMonthList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panSelectMonthList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panSelectMonthList.Controls.Add(this.label56, 1, 5);
            this.panSelectMonthList.Controls.Add(this.label55, 0, 5);
            this.panSelectMonthList.Controls.Add(this.label54, 1, 4);
            this.panSelectMonthList.Controls.Add(this.label53, 0, 4);
            this.panSelectMonthList.Controls.Add(this.label52, 1, 3);
            this.panSelectMonthList.Controls.Add(this.label51, 0, 3);
            this.panSelectMonthList.Controls.Add(this.label50, 1, 2);
            this.panSelectMonthList.Controls.Add(this.label49, 0, 2);
            this.panSelectMonthList.Controls.Add(this.label48, 1, 1);
            this.panSelectMonthList.Controls.Add(this.label47, 0, 1);
            this.panSelectMonthList.Controls.Add(this.label44, 1, 0);
            this.panSelectMonthList.Controls.Add(this.label43, 0, 0);
            this.panSelectMonthList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSelectMonthList.Location = new System.Drawing.Point(0, 0);
            this.panSelectMonthList.Name = "panSelectMonthList";
            this.panSelectMonthList.RowCount = 6;
            this.panSelectMonthList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panSelectMonthList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panSelectMonthList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panSelectMonthList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panSelectMonthList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panSelectMonthList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.panSelectMonthList.Size = new System.Drawing.Size(128, 239);
            this.panSelectMonthList.TabIndex = 0;
            // 
            // label56
            // 
            this.label56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label56.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label56.ForeColor = System.Drawing.Color.White;
            this.label56.Location = new System.Drawing.Point(67, 195);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(58, 44);
            this.label56.TabIndex = 11;
            this.label56.Tag = "12";
            this.label56.Text = "12月";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label55.ForeColor = System.Drawing.Color.White;
            this.label55.Location = new System.Drawing.Point(3, 195);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(58, 44);
            this.label55.TabIndex = 10;
            this.label55.Tag = "11";
            this.label55.Text = "11月";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label54.ForeColor = System.Drawing.Color.White;
            this.label54.Location = new System.Drawing.Point(67, 156);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(58, 39);
            this.label54.TabIndex = 9;
            this.label54.Tag = "10";
            this.label54.Text = "10月";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label53.ForeColor = System.Drawing.Color.White;
            this.label53.Location = new System.Drawing.Point(3, 156);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(58, 39);
            this.label53.TabIndex = 8;
            this.label53.Tag = "9";
            this.label53.Text = "09月";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label52.ForeColor = System.Drawing.Color.White;
            this.label52.Location = new System.Drawing.Point(67, 117);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(58, 39);
            this.label52.TabIndex = 7;
            this.label52.Tag = "8";
            this.label52.Text = "08月";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label51.ForeColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(3, 117);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(58, 39);
            this.label51.TabIndex = 6;
            this.label51.Tag = "7";
            this.label51.Text = "07月";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(67, 78);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(58, 39);
            this.label50.TabIndex = 5;
            this.label50.Tag = "6";
            this.label50.Text = "06月";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label49.ForeColor = System.Drawing.Color.White;
            this.label49.Location = new System.Drawing.Point(3, 78);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(58, 39);
            this.label49.TabIndex = 4;
            this.label49.Tag = "5";
            this.label49.Text = "05月";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label48.ForeColor = System.Drawing.Color.White;
            this.label48.Location = new System.Drawing.Point(67, 39);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(58, 39);
            this.label48.TabIndex = 3;
            this.label48.Tag = "4";
            this.label48.Text = "04月";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label47.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.ForeColor = System.Drawing.Color.White;
            this.label47.Location = new System.Drawing.Point(3, 39);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(58, 39);
            this.label47.TabIndex = 2;
            this.label47.Tag = "3";
            this.label47.Text = "03月";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(67, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(58, 39);
            this.label44.TabIndex = 1;
            this.label44.Tag = "2";
            this.label44.Text = "02月";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(3, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(58, 39);
            this.label43.TabIndex = 0;
            this.label43.Tag = "1";
            this.label43.Text = "01月";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ucCalendarNotes_Week1
            // 
            this.ucCalendarNotes_Week1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucCalendarNotes_Week1.BackColor = System.Drawing.Color.White;
            this.ucCalendarNotes_Week1.CurrentTime = new System.DateTime(2020, 8, 14, 21, 46, 6, 827);
            this.ucCalendarNotes_Week1.DataSource = null;
            this.ucCalendarNotes_Week1.Location = new System.Drawing.Point(1, 1);
            this.ucCalendarNotes_Week1.Name = "ucCalendarNotes_Week1";
            this.ucCalendarNotes_Week1.ShowAddButton = true;
            this.ucCalendarNotes_Week1.ShowCloseButton = true;
            this.ucCalendarNotes_Week1.Size = new System.Drawing.Size(439, 344);
            this.ucCalendarNotes_Week1.SplitLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.ucCalendarNotes_Week1.SplitTimeForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.ucCalendarNotes_Week1.TabIndex = 3;
            this.ucCalendarNotes_Week1.Visible = false;
            this.ucCalendarNotes_Week1.ClickNote += new HZH_Controls.Controls.UCCalendarNotes_Week.ClickNoteEvent(this.ucCalendarNotes_Week1_ClickNote);
            this.ucCalendarNotes_Week1.CloseClick += new System.EventHandler(this.ucCalendarNotes_Week1_CloseClick);
            // 
            // ucSplitLine_H2
            // 
            this.ucSplitLine_H2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSplitLine_H2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ucSplitLine_H2.Location = new System.Drawing.Point(1, 345);
            this.ucSplitLine_H2.Name = "ucSplitLine_H2";
            this.ucSplitLine_H2.Size = new System.Drawing.Size(439, 1);
            this.ucSplitLine_H2.TabIndex = 22;
            this.ucSplitLine_H2.TabStop = false;
            // 
            // ucSplitLine_V4
            // 
            this.ucSplitLine_V4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSplitLine_V4.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucSplitLine_V4.Location = new System.Drawing.Point(0, 0);
            this.ucSplitLine_V4.Name = "ucSplitLine_V4";
            this.ucSplitLine_V4.Size = new System.Drawing.Size(1, 346);
            this.ucSplitLine_V4.TabIndex = 30;
            this.ucSplitLine_V4.TabStop = false;
            // 
            // ucSplitLine_V5
            // 
            this.ucSplitLine_V5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucSplitLine_V5.Dock = System.Windows.Forms.DockStyle.Right;
            this.ucSplitLine_V5.Location = new System.Drawing.Point(440, 0);
            this.ucSplitLine_V5.Name = "ucSplitLine_V5";
            this.ucSplitLine_V5.Size = new System.Drawing.Size(1, 346);
            this.ucSplitLine_V5.TabIndex = 31;
            this.ucSplitLine_V5.TabStop = false;
            // 
            // UCCalendarNotes
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucCalendarNotes_Week1);
            this.Controls.Add(this.panSelectMonth);
            this.Controls.Add(this.panSelectYear);
            this.Controls.Add(this.panDay);
            this.Controls.Add(this.panWeek);
            this.Controls.Add(this.panTop);
            this.Controls.Add(this.ucSplitLine_H2);
            this.Controls.Add(this.ucSplitLine_V4);
            this.Controls.Add(this.ucSplitLine_V5);
            this.Name = "UCCalendarNotes";
            this.Size = new System.Drawing.Size(441, 346);
            this.panTop.ResumeLayout(false);
            this.panTop.PerformLayout();
            this.panWeek.ResumeLayout(false);
            this.panDay.ResumeLayout(false);
            this.panSelectYear.ResumeLayout(false);
            this.panSelectYearList.ResumeLayout(false);
            this.panSelectMonth.ResumeLayout(false);
            this.panSelectMonthList.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panTop;
        private System.Windows.Forms.Label lblMouth;
        private System.Windows.Forms.Label lblYear;
        private UCBtnExt btnMouthNext;
        private UCBtnExt btnYearNext;
        private UCBtnExt btbMouthLast;
        private UCBtnExt btnYearLast;
        private System.Windows.Forms.TableLayoutPanel panWeek;
        private System.Windows.Forms.Label lblWeek_7;
        private System.Windows.Forms.Label lblWeek_6;
        private System.Windows.Forms.Label lblWeek_5;
        private System.Windows.Forms.Label lblWeek_4;
        private System.Windows.Forms.Label lblWeek_3;
        private System.Windows.Forms.Label lblWeek_2;
        private System.Windows.Forms.Label lblWeek_1;
        private System.Windows.Forms.TableLayoutPanel panDay;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panSelectYear;
        private System.Windows.Forms.TableLayoutPanel panSelectYearList;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label lblYearNextList;
        private System.Windows.Forms.Label lblYearLastList;
        private System.Windows.Forms.Panel panSelectMonth;
        private System.Windows.Forms.TableLayoutPanel panSelectMonthList;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private UCSplitLine_H ucSplitLine_H2;
        private UCSplitLine_V ucSplitLine_V4;
        private UCSplitLine_V ucSplitLine_V5;
        private UCCalendarNotes_Week ucCalendarNotes_Week1;
    }
}
