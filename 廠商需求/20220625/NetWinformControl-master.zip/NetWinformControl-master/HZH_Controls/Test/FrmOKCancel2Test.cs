﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FrmOKCancel2Test : HZH_Controls.Forms.FrmWithOKCancel2
    {
        public FrmOKCancel2Test()
        {
            InitializeComponent();
        }
    }
}
