﻿namespace Test.UC
{
    partial class UCTestTimeLine
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            HZH_Controls.Controls.TimeLineItem timeLineItem5 = new HZH_Controls.Controls.TimeLineItem();
            HZH_Controls.Controls.TimeLineItem timeLineItem6 = new HZH_Controls.Controls.TimeLineItem();
            HZH_Controls.Controls.TimeLineItem timeLineItem7 = new HZH_Controls.Controls.TimeLineItem();
            HZH_Controls.Controls.TimeLineItem timeLineItem8 = new HZH_Controls.Controls.TimeLineItem();
            this.ucTimeLine1 = new HZH_Controls.Controls.UCTimeLine();
            this.SuspendLayout();
            // 
            // ucTimeLine1
            // 
            this.ucTimeLine1.AutoScroll = true;
            this.ucTimeLine1.DetailsFont = new System.Drawing.Font("微软雅黑", 10F);
            this.ucTimeLine1.DetailsForcolor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(147)))), ((int)(((byte)(153)))));
            this.ucTimeLine1.Dock = System.Windows.Forms.DockStyle.Fill;
            timeLineItem5.Details = "2019年07月发生了一件大事，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷" +
    "，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，然后王二麻子他爹王咔嚓出生了。";
            timeLineItem5.Title = "2019年07月";
            timeLineItem6.Details = "2019年08月发生了一件大事，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷" +
    "，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，然后王二麻子他爹王咔嚓出生了。";
            timeLineItem6.Title = "2019年08月";
            timeLineItem7.Details = "2019年09月发生了一件大事，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷" +
    "，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，然后王二麻子他爹王咔嚓出生了。";
            timeLineItem7.Title = "2019年09月";
            timeLineItem8.Details = "2019年10月发生了一件大事，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷" +
    "，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，咔嚓一声打了一个炸雷，然后王二麻子他爹王咔嚓出生了。";
            timeLineItem8.Title = "2019年10月";
            this.ucTimeLine1.Items = new HZH_Controls.Controls.TimeLineItem[] {
        timeLineItem5,
        timeLineItem6,
        timeLineItem7,
        timeLineItem8};
            this.ucTimeLine1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(147)))), ((int)(((byte)(153)))));
            this.ucTimeLine1.Location = new System.Drawing.Point(0, 0);
            this.ucTimeLine1.Name = "ucTimeLine1";
            this.ucTimeLine1.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.ucTimeLine1.Size = new System.Drawing.Size(768, 542);
            this.ucTimeLine1.TabIndex = 0;
            this.ucTimeLine1.TitleFont = new System.Drawing.Font("微软雅黑", 14F);
            this.ucTimeLine1.TitleForcolor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(49)))), ((int)(((byte)(51)))));
            // 
            // UCTestTimeLine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucTimeLine1);
            this.Name = "UCTestTimeLine";
            this.Size = new System.Drawing.Size(768, 542);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCTimeLine ucTimeLine1;







    }
}
