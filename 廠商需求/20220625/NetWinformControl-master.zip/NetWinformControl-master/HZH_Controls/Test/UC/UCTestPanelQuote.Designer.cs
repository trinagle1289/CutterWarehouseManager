﻿namespace Test.UC
{
    partial class UCTestPanelQuote
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucPanelQuote5 = new HZH_Controls.Controls.UCPanelQuote();
            this.ucPanelQuote4 = new HZH_Controls.Controls.UCPanelQuote();
            this.ucPanelQuote3 = new HZH_Controls.Controls.UCPanelQuote();
            this.ucPanelQuote2 = new HZH_Controls.Controls.UCPanelQuote();
            this.label2 = new System.Windows.Forms.Label();
            this.ucPanelQuote1 = new HZH_Controls.Controls.UCPanelQuote();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ucPanelQuote5.SuspendLayout();
            this.ucPanelQuote4.SuspendLayout();
            this.ucPanelQuote3.SuspendLayout();
            this.ucPanelQuote2.SuspendLayout();
            this.ucPanelQuote1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ucPanelQuote5
            // 
            this.ucPanelQuote5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(147)))), ((int)(((byte)(153)))));
            this.ucPanelQuote5.Controls.Add(this.label5);
            this.ucPanelQuote5.LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(147)))), ((int)(((byte)(153)))));
            this.ucPanelQuote5.Location = new System.Drawing.Point(14, 389);
            this.ucPanelQuote5.Name = "ucPanelQuote5";
            this.ucPanelQuote5.Padding = new System.Windows.Forms.Padding(5, 1, 1, 1);
            this.ucPanelQuote5.Size = new System.Drawing.Size(336, 71);
            this.ucPanelQuote5.TabIndex = 0;
            // 
            // ucPanelQuote4
            // 
            this.ucPanelQuote4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(238)))), ((int)(((byte)(245)))));
            this.ucPanelQuote4.Controls.Add(this.label4);
            this.ucPanelQuote4.LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(162)))), ((int)(((byte)(60)))));
            this.ucPanelQuote4.Location = new System.Drawing.Point(14, 295);
            this.ucPanelQuote4.Name = "ucPanelQuote4";
            this.ucPanelQuote4.Padding = new System.Windows.Forms.Padding(5, 1, 1, 1);
            this.ucPanelQuote4.Size = new System.Drawing.Size(336, 71);
            this.ucPanelQuote4.TabIndex = 0;
            // 
            // ucPanelQuote3
            // 
            this.ucPanelQuote3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ucPanelQuote3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(194)))), ((int)(((byte)(58)))));
            this.ucPanelQuote3.Controls.Add(this.label3);
            this.ucPanelQuote3.LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(194)))), ((int)(((byte)(58)))));
            this.ucPanelQuote3.Location = new System.Drawing.Point(14, 196);
            this.ucPanelQuote3.Name = "ucPanelQuote3";
            this.ucPanelQuote3.Padding = new System.Windows.Forms.Padding(5, 1, 1, 1);
            this.ucPanelQuote3.Size = new System.Drawing.Size(336, 71);
            this.ucPanelQuote3.TabIndex = 0;
            // 
            // ucPanelQuote2
            // 
            this.ucPanelQuote2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(158)))), ((int)(((byte)(255)))));
            this.ucPanelQuote2.Controls.Add(this.label2);
            this.ucPanelQuote2.LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(158)))), ((int)(((byte)(255)))));
            this.ucPanelQuote2.Location = new System.Drawing.Point(14, 103);
            this.ucPanelQuote2.Name = "ucPanelQuote2";
            this.ucPanelQuote2.Padding = new System.Windows.Forms.Padding(5, 1, 1, 1);
            this.ucPanelQuote2.Size = new System.Drawing.Size(336, 71);
            this.ucPanelQuote2.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(5, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(330, 69);
            this.label2.TabIndex = 1;
            this.label2.Text = "这是一个自定义样式的区块";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ucPanelQuote1
            // 
            this.ucPanelQuote1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(238)))), ((int)(((byte)(245)))));
            this.ucPanelQuote1.Controls.Add(this.label1);
            this.ucPanelQuote1.LeftColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(108)))), ((int)(((byte)(108)))));
            this.ucPanelQuote1.Location = new System.Drawing.Point(14, 14);
            this.ucPanelQuote1.Name = "ucPanelQuote1";
            this.ucPanelQuote1.Padding = new System.Windows.Forms.Padding(5, 1, 1, 1);
            this.ucPanelQuote1.Size = new System.Drawing.Size(336, 71);
            this.ucPanelQuote1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(5, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 69);
            this.label1.TabIndex = 0;
            this.label1.Text = "这是一个默认样式的区块";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(5, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(330, 69);
            this.label3.TabIndex = 2;
            this.label3.Text = "这是一个自定义样式的区块";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(5, 1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(330, 69);
            this.label4.TabIndex = 2;
            this.label4.Text = "这是一个自定义样式的区块";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(5, 1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(330, 69);
            this.label5.TabIndex = 2;
            this.label5.Text = "这是一个自定义样式的区块";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // UCTestPanelQuote
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucPanelQuote5);
            this.Controls.Add(this.ucPanelQuote4);
            this.Controls.Add(this.ucPanelQuote3);
            this.Controls.Add(this.ucPanelQuote2);
            this.Controls.Add(this.ucPanelQuote1);
            this.Name = "UCTestPanelQuote";
            this.Size = new System.Drawing.Size(902, 514);
            this.ucPanelQuote5.ResumeLayout(false);
            this.ucPanelQuote4.ResumeLayout(false);
            this.ucPanelQuote3.ResumeLayout(false);
            this.ucPanelQuote2.ResumeLayout(false);
            this.ucPanelQuote1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCPanelQuote ucPanelQuote1;
        private System.Windows.Forms.Label label1;
        private HZH_Controls.Controls.UCPanelQuote ucPanelQuote2;
        private System.Windows.Forms.Label label2;
        private HZH_Controls.Controls.UCPanelQuote ucPanelQuote3;
        private HZH_Controls.Controls.UCPanelQuote ucPanelQuote4;
        private HZH_Controls.Controls.UCPanelQuote ucPanelQuote5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;

    }
}
