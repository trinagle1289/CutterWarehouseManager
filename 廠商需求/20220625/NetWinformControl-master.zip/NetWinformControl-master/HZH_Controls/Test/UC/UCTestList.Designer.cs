﻿namespace Test.UC
{
    partial class UCTestList
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucListExt1 = new HZH_Controls.Controls.UCListExt();
            this.ucSplitLine_V1 = new HZH_Controls.Controls.UCSplitLine_V();
            this.ucSplitLine_V2 = new HZH_Controls.Controls.UCSplitLine_V();
            this.ucListExt2 = new HZH_Controls.Controls.UCListExt();
            this.SuspendLayout();
            // 
            // ucListExt1
            // 
            this.ucListExt1.AutoScroll = true;
            this.ucListExt1.AutoSelectFirst = true;
            this.ucListExt1.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucListExt1.ItemBackColor = System.Drawing.Color.White;
            this.ucListExt1.ItemForeColor = System.Drawing.Color.Black;
            this.ucListExt1.ItemForeColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucListExt1.ItemHeight = 60;
            this.ucListExt1.ItemSelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucListExt1.ItemSelectedForeColor = System.Drawing.Color.White;
            this.ucListExt1.ItemSelectedForeColor2 = System.Drawing.Color.White;
            this.ucListExt1.Location = new System.Drawing.Point(0, 0);
            this.ucListExt1.Name = "ucListExt1";
            this.ucListExt1.SelectedCanClick = false;
            this.ucListExt1.Size = new System.Drawing.Size(234, 615);
            this.ucListExt1.TabIndex = 1;
            this.ucListExt1.Title2Font = new System.Drawing.Font("微软雅黑", 14F);
            this.ucListExt1.TitleFont = new System.Drawing.Font("微软雅黑", 15F);
            // 
            // ucSplitLine_V1
            // 
            this.ucSplitLine_V1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V1.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucSplitLine_V1.Location = new System.Drawing.Point(234, 0);
            this.ucSplitLine_V1.Name = "ucSplitLine_V1";
            this.ucSplitLine_V1.Size = new System.Drawing.Size(1, 615);
            this.ucSplitLine_V1.TabIndex = 2;
            this.ucSplitLine_V1.TabStop = false;
            // 
            // ucSplitLine_V2
            // 
            this.ucSplitLine_V2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucSplitLine_V2.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucSplitLine_V2.Location = new System.Drawing.Point(469, 0);
            this.ucSplitLine_V2.Name = "ucSplitLine_V2";
            this.ucSplitLine_V2.Size = new System.Drawing.Size(1, 615);
            this.ucSplitLine_V2.TabIndex = 4;
            this.ucSplitLine_V2.TabStop = false;
            // 
            // ucListExt2
            // 
            this.ucListExt2.AutoScroll = true;
            this.ucListExt2.AutoSelectFirst = true;
            this.ucListExt2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(43)))), ((int)(((byte)(51)))));
            this.ucListExt2.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucListExt2.ItemBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(43)))), ((int)(((byte)(51)))));
            this.ucListExt2.ItemForeColor = System.Drawing.Color.White;
            this.ucListExt2.ItemForeColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucListExt2.ItemHeight = 60;
            this.ucListExt2.ItemSelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(73)))));
            this.ucListExt2.ItemSelectedForeColor = System.Drawing.Color.White;
            this.ucListExt2.ItemSelectedForeColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ucListExt2.Location = new System.Drawing.Point(235, 0);
            this.ucListExt2.Name = "ucListExt2";
            this.ucListExt2.SelectedCanClick = false;
            this.ucListExt2.Size = new System.Drawing.Size(234, 615);
            this.ucListExt2.TabIndex = 3;
            this.ucListExt2.Title2Font = new System.Drawing.Font("微软雅黑", 12F);
            this.ucListExt2.TitleFont = new System.Drawing.Font("微软雅黑", 15F);
            // 
            // UCTestList
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucSplitLine_V2);
            this.Controls.Add(this.ucListExt2);
            this.Controls.Add(this.ucSplitLine_V1);
            this.Controls.Add(this.ucListExt1);
            this.Name = "UCTestList";
            this.Size = new System.Drawing.Size(640, 615);
            this.Load += new System.EventHandler(this.UCTestList_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCListExt ucListExt1;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V1;
        private HZH_Controls.Controls.UCSplitLine_V ucSplitLine_V2;
        private HZH_Controls.Controls.UCListExt ucListExt2;
    }
}
