﻿namespace Test.UC
{
    partial class UCTestRadarChart
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            HZH_Controls.Controls.RadarLine radarLine1 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarLine radarLine2 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarLine radarLine3 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarPosition radarPosition1 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition2 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition3 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition4 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition5 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition6 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarLine radarLine4 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarLine radarLine5 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarPosition radarPosition7 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition8 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition9 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition10 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition11 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition12 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition13 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarLine radarLine6 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarLine radarLine7 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarPosition radarPosition14 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition15 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition16 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition17 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition18 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition19 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarLine radarLine8 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarLine radarLine9 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarPosition radarPosition20 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition21 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition22 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition23 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition24 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition25 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarLine radarLine10 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarLine radarLine11 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarPosition radarPosition26 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition27 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition28 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition29 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition30 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition31 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarLine radarLine12 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarLine radarLine13 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarLine radarLine14 = new HZH_Controls.Controls.RadarLine();
            HZH_Controls.Controls.RadarPosition radarPosition32 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition33 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition34 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition35 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition36 = new HZH_Controls.Controls.RadarPosition();
            HZH_Controls.Controls.RadarPosition radarPosition37 = new HZH_Controls.Controls.RadarPosition();
            this.ucRadarChart4 = new HZH_Controls.Controls.UCRadarChart();
            this.ucRadarChart3 = new HZH_Controls.Controls.UCRadarChart();
            this.ucRadarChart5 = new HZH_Controls.Controls.UCRadarChart();
            this.ucRadarChart2 = new HZH_Controls.Controls.UCRadarChart();
            this.ucRadarChart1 = new HZH_Controls.Controls.UCRadarChart();
            this.ucRadarChart6 = new HZH_Controls.Controls.UCRadarChart();
            this.SuspendLayout();
            // 
            // ucRadarChart4
            // 
            this.ucRadarChart4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            radarLine1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine1.Name = "上午";
            radarLine1.ShowValueText = true;
            radarLine1.Values = new double[] {
        88D,
        23D,
        94D,
        83D,
        21D,
        90D};
            radarLine2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(39)))), ((int)(((byte)(176)))));
            radarLine2.Name = "下午";
            radarLine2.ShowValueText = false;
            radarLine2.Values = new double[] {
        89D,
        34D,
        71D,
        89D,
        53D,
        65D};
            radarLine3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine3.LineColor = System.Drawing.Color.Green;
            radarLine3.Name = "晚上";
            radarLine3.ShowValueText = false;
            radarLine3.Values = new double[] {
        10D,
        20D,
        30D,
        40D,
        50D,
        60D};
            this.ucRadarChart4.Lines = new HZH_Controls.Controls.RadarLine[] {
        radarLine1,
        radarLine2,
        radarLine3};
            this.ucRadarChart4.Location = new System.Drawing.Point(394, 413);
            this.ucRadarChart4.Name = "ucRadarChart4";
            radarPosition1.MaxValue = 100D;
            radarPosition1.MinValue = 0D;
            radarPosition1.Text = "SO2";
            radarPosition2.MaxValue = 100D;
            radarPosition2.MinValue = 0D;
            radarPosition2.Text = "NO2";
            radarPosition3.MaxValue = 100D;
            radarPosition3.MinValue = 0D;
            radarPosition3.Text = "CO";
            radarPosition4.MaxValue = 100D;
            radarPosition4.MinValue = 0D;
            radarPosition4.Text = "PM2.5";
            radarPosition5.MaxValue = 100D;
            radarPosition5.MinValue = 0D;
            radarPosition5.Text = "PM10";
            radarPosition6.MaxValue = 100D;
            radarPosition6.MinValue = 0D;
            radarPosition6.Text = "AQI";
            this.ucRadarChart4.RadarPositions = new HZH_Controls.Controls.RadarPosition[] {
        radarPosition1,
        radarPosition2,
        radarPosition3,
        radarPosition4,
        radarPosition5,
        radarPosition6};
            this.ucRadarChart4.ShowCheck = false;
            this.ucRadarChart4.ShowLinesIndex = new int[] {
        0,
        1,
        2};
            this.ucRadarChart4.Size = new System.Drawing.Size(337, 326);
            this.ucRadarChart4.SplitCount = 5;
            this.ucRadarChart4.SplitEvenColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucRadarChart4.SplitOddColor = System.Drawing.Color.White;
            this.ucRadarChart4.TabIndex = 0;
            this.ucRadarChart4.Title = "空气污染度";
            this.ucRadarChart4.TitleColor = System.Drawing.Color.Black;
            this.ucRadarChart4.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucRadarChart4.UseRoundSplit = false;
            // 
            // ucRadarChart3
            // 
            this.ucRadarChart3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            radarLine4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine4.Name = "line0";
            radarLine4.ShowValueText = true;
            radarLine4.Values = new double[] {
        88D,
        23D,
        94D,
        83D,
        21D,
        90D,
        0D};
            radarLine5.FillColor = null;
            radarLine5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(39)))), ((int)(((byte)(176)))));
            radarLine5.Name = "line1";
            radarLine5.ShowValueText = false;
            radarLine5.Values = new double[] {
        89D,
        34D,
        71D,
        89D,
        53D,
        65D,
        0D};
            this.ucRadarChart3.Lines = new HZH_Controls.Controls.RadarLine[] {
        radarLine4,
        radarLine5};
            this.ucRadarChart3.Location = new System.Drawing.Point(55, 413);
            this.ucRadarChart3.Name = "ucRadarChart3";
            radarPosition7.MaxValue = 100D;
            radarPosition7.MinValue = 0D;
            radarPosition7.Text = "Item1";
            radarPosition8.MaxValue = 100D;
            radarPosition8.MinValue = 0D;
            radarPosition8.Text = "Item2";
            radarPosition9.MaxValue = 100D;
            radarPosition9.MinValue = 0D;
            radarPosition9.Text = "Item3";
            radarPosition10.MaxValue = 100D;
            radarPosition10.MinValue = 0D;
            radarPosition10.Text = "Item4";
            radarPosition11.MaxValue = 100D;
            radarPosition11.MinValue = 0D;
            radarPosition11.Text = "Item5";
            radarPosition12.MaxValue = 100D;
            radarPosition12.MinValue = 0D;
            radarPosition12.Text = "Item6";
            radarPosition13.MaxValue = 100D;
            radarPosition13.MinValue = 0D;
            radarPosition13.Text = "item7";
            this.ucRadarChart3.RadarPositions = new HZH_Controls.Controls.RadarPosition[] {
        radarPosition7,
        radarPosition8,
        radarPosition9,
        radarPosition10,
        radarPosition11,
        radarPosition12,
        radarPosition13};
            this.ucRadarChart3.ShowCheck = false;
            this.ucRadarChart3.ShowLinesIndex = new int[] {
        0,
        1};
            this.ucRadarChart3.Size = new System.Drawing.Size(337, 326);
            this.ucRadarChart3.SplitCount = 5;
            this.ucRadarChart3.SplitEvenColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucRadarChart3.SplitOddColor = System.Drawing.Color.White;
            this.ucRadarChart3.TabIndex = 0;
            this.ucRadarChart3.Title = "有标题、填充颜色、数值的图表";
            this.ucRadarChart3.TitleColor = System.Drawing.Color.Black;
            this.ucRadarChart3.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucRadarChart3.UseRoundSplit = false;
            // 
            // ucRadarChart5
            // 
            this.ucRadarChart5.BackColor = System.Drawing.Color.Black;
            this.ucRadarChart5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ucRadarChart5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            radarLine6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine6.Name = "line0";
            radarLine6.ShowValueText = false;
            radarLine6.Values = new double[] {
        88D,
        23D,
        94D,
        83D,
        21D,
        90D};
            radarLine7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(39)))), ((int)(((byte)(176)))));
            radarLine7.Name = "line1";
            radarLine7.ShowValueText = false;
            radarLine7.Values = new double[] {
        89D,
        34D,
        71D,
        89D,
        53D,
        65D};
            this.ucRadarChart5.Lines = new HZH_Controls.Controls.RadarLine[] {
        radarLine6,
        radarLine7};
            this.ucRadarChart5.Location = new System.Drawing.Point(737, 71);
            this.ucRadarChart5.Name = "ucRadarChart5";
            radarPosition14.MaxValue = 100D;
            radarPosition14.MinValue = 0D;
            radarPosition14.Text = "Item1";
            radarPosition15.MaxValue = 100D;
            radarPosition15.MinValue = 0D;
            radarPosition15.Text = "Item2";
            radarPosition16.MaxValue = 100D;
            radarPosition16.MinValue = 0D;
            radarPosition16.Text = "Item3";
            radarPosition17.MaxValue = 100D;
            radarPosition17.MinValue = 0D;
            radarPosition17.Text = "Item4";
            radarPosition18.MaxValue = 100D;
            radarPosition18.MinValue = 0D;
            radarPosition18.Text = "Item5";
            radarPosition19.MaxValue = 100D;
            radarPosition19.MinValue = 0D;
            radarPosition19.Text = "Item6";
            this.ucRadarChart5.RadarPositions = new HZH_Controls.Controls.RadarPosition[] {
        radarPosition14,
        radarPosition15,
        radarPosition16,
        radarPosition17,
        radarPosition18,
        radarPosition19};
            this.ucRadarChart5.ShowCheck = false;
            this.ucRadarChart5.ShowLinesIndex = new int[] {
        0,
        1};
            this.ucRadarChart5.Size = new System.Drawing.Size(337, 336);
            this.ucRadarChart5.SplitCount = 5;
            this.ucRadarChart5.SplitEvenColor = System.Drawing.Color.Black;
            this.ucRadarChart5.SplitOddColor = System.Drawing.Color.Black;
            this.ucRadarChart5.TabIndex = 0;
            this.ucRadarChart5.Title = "有标题和填充颜色的图表";
            this.ucRadarChart5.TitleColor = System.Drawing.Color.White;
            this.ucRadarChart5.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucRadarChart5.UseRoundSplit = true;
            // 
            // ucRadarChart2
            // 
            this.ucRadarChart2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            radarLine8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine8.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine8.Name = "line0";
            radarLine8.ShowValueText = false;
            radarLine8.Values = new double[] {
        88D,
        23D,
        94D,
        83D,
        21D,
        90D};
            radarLine9.FillColor = null;
            radarLine9.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(39)))), ((int)(((byte)(176)))));
            radarLine9.Name = "line1";
            radarLine9.ShowValueText = false;
            radarLine9.Values = new double[] {
        89D,
        34D,
        71D,
        89D,
        53D,
        65D};
            this.ucRadarChart2.Lines = new HZH_Controls.Controls.RadarLine[] {
        radarLine8,
        radarLine9};
            this.ucRadarChart2.Location = new System.Drawing.Point(394, 71);
            this.ucRadarChart2.Name = "ucRadarChart2";
            radarPosition20.MaxValue = 100D;
            radarPosition20.MinValue = 0D;
            radarPosition20.Text = "Item1";
            radarPosition21.MaxValue = 100D;
            radarPosition21.MinValue = 0D;
            radarPosition21.Text = "Item2";
            radarPosition22.MaxValue = 100D;
            radarPosition22.MinValue = 0D;
            radarPosition22.Text = "Item3";
            radarPosition23.MaxValue = 100D;
            radarPosition23.MinValue = 0D;
            radarPosition23.Text = "Item4";
            radarPosition24.MaxValue = 100D;
            radarPosition24.MinValue = 0D;
            radarPosition24.Text = "Item5";
            radarPosition25.MaxValue = 100D;
            radarPosition25.MinValue = 0D;
            radarPosition25.Text = "Item6";
            this.ucRadarChart2.RadarPositions = new HZH_Controls.Controls.RadarPosition[] {
        radarPosition20,
        radarPosition21,
        radarPosition22,
        radarPosition23,
        radarPosition24,
        radarPosition25};
            this.ucRadarChart2.ShowCheck = false;
            this.ucRadarChart2.ShowLinesIndex = new int[] {
        0,
        1};
            this.ucRadarChart2.Size = new System.Drawing.Size(337, 336);
            this.ucRadarChart2.SplitCount = 5;
            this.ucRadarChart2.SplitEvenColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucRadarChart2.SplitOddColor = System.Drawing.Color.White;
            this.ucRadarChart2.TabIndex = 0;
            this.ucRadarChart2.Title = "有标题和填充颜色的图表";
            this.ucRadarChart2.TitleColor = System.Drawing.Color.Black;
            this.ucRadarChart2.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucRadarChart2.UseRoundSplit = false;
            // 
            // ucRadarChart1
            // 
            this.ucRadarChart1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            radarLine10.FillColor = null;
            radarLine10.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine10.Name = "line0";
            radarLine10.ShowValueText = false;
            radarLine10.Values = new double[] {
        88D,
        23D,
        94D,
        83D,
        21D,
        90D};
            radarLine11.FillColor = null;
            radarLine11.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(39)))), ((int)(((byte)(176)))));
            radarLine11.Name = "line1";
            radarLine11.ShowValueText = false;
            radarLine11.Values = new double[] {
        89D,
        34D,
        71D,
        89D,
        53D,
        65D};
            this.ucRadarChart1.Lines = new HZH_Controls.Controls.RadarLine[] {
        radarLine10,
        radarLine11};
            this.ucRadarChart1.Location = new System.Drawing.Point(55, 71);
            this.ucRadarChart1.Name = "ucRadarChart1";
            radarPosition26.MaxValue = 100D;
            radarPosition26.MinValue = 0D;
            radarPosition26.Text = "Item1";
            radarPosition27.MaxValue = 100D;
            radarPosition27.MinValue = 0D;
            radarPosition27.Text = "Item2";
            radarPosition28.MaxValue = 100D;
            radarPosition28.MinValue = 0D;
            radarPosition28.Text = "Item3";
            radarPosition29.MaxValue = 100D;
            radarPosition29.MinValue = 0D;
            radarPosition29.Text = "Item4";
            radarPosition30.MaxValue = 100D;
            radarPosition30.MinValue = 0D;
            radarPosition30.Text = "Item5";
            radarPosition31.MaxValue = 100D;
            radarPosition31.MinValue = 0D;
            radarPosition31.Text = "Item6";
            this.ucRadarChart1.RadarPositions = new HZH_Controls.Controls.RadarPosition[] {
        radarPosition26,
        radarPosition27,
        radarPosition28,
        radarPosition29,
        radarPosition30,
        radarPosition31};
            this.ucRadarChart1.ShowCheck = true;
            this.ucRadarChart1.ShowLinesIndex = new int[] {
        0,
        1};
            this.ucRadarChart1.Size = new System.Drawing.Size(340, 336);
            this.ucRadarChart1.SplitCount = 5;
            this.ucRadarChart1.SplitEvenColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucRadarChart1.SplitOddColor = System.Drawing.Color.White;
            this.ucRadarChart1.TabIndex = 0;
            this.ucRadarChart1.Title = "";
            this.ucRadarChart1.TitleColor = System.Drawing.Color.Black;
            this.ucRadarChart1.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucRadarChart1.UseRoundSplit = false;
            // 
            // ucRadarChart6
            // 
            this.ucRadarChart6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            radarLine12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine12.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine12.Name = "上午";
            radarLine12.ShowValueText = true;
            radarLine12.Values = new double[] {
        88D,
        23D,
        94D,
        83D,
        21D,
        90D};
            radarLine13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine13.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(39)))), ((int)(((byte)(176)))));
            radarLine13.Name = "下午";
            radarLine13.ShowValueText = false;
            radarLine13.Values = new double[] {
        89D,
        34D,
        71D,
        89D,
        53D,
        65D};
            radarLine14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(243)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            radarLine14.LineColor = System.Drawing.Color.Green;
            radarLine14.Name = "晚上";
            radarLine14.ShowValueText = false;
            radarLine14.Values = new double[] {
        10D,
        20D,
        30D,
        40D,
        50D,
        60D};
            this.ucRadarChart6.Lines = new HZH_Controls.Controls.RadarLine[] {
        radarLine12,
        radarLine13,
        radarLine14};
            this.ucRadarChart6.Location = new System.Drawing.Point(737, 413);
            this.ucRadarChart6.Name = "ucRadarChart6";
            radarPosition32.MaxValue = 100D;
            radarPosition32.MinValue = 0D;
            radarPosition32.Text = "SO2";
            radarPosition33.MaxValue = 100D;
            radarPosition33.MinValue = 0D;
            radarPosition33.Text = "NO2";
            radarPosition34.MaxValue = 100D;
            radarPosition34.MinValue = 0D;
            radarPosition34.Text = "CO";
            radarPosition35.MaxValue = 100D;
            radarPosition35.MinValue = 0D;
            radarPosition35.Text = "PM2.5";
            radarPosition36.MaxValue = 100D;
            radarPosition36.MinValue = 0D;
            radarPosition36.Text = "PM10";
            radarPosition37.MaxValue = 100D;
            radarPosition37.MinValue = 0D;
            radarPosition37.Text = "AQI";
            this.ucRadarChart6.RadarPositions = new HZH_Controls.Controls.RadarPosition[] {
        radarPosition32,
        radarPosition33,
        radarPosition34,
        radarPosition35,
        radarPosition36,
        radarPosition37};
            this.ucRadarChart6.ShowCheck = false;
            this.ucRadarChart6.ShowLinesIndex = new int[] {
        0,
        1,
        2};
            this.ucRadarChart6.Size = new System.Drawing.Size(337, 326);
            this.ucRadarChart6.SplitCount = 5;
            this.ucRadarChart6.SplitEvenColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.ucRadarChart6.SplitOddColor = System.Drawing.Color.White;
            this.ucRadarChart6.TabIndex = 0;
            this.ucRadarChart6.Title = "空气污染度(圆形)";
            this.ucRadarChart6.TitleColor = System.Drawing.Color.Black;
            this.ucRadarChart6.TitleFont = new System.Drawing.Font("微软雅黑", 12F);
            this.ucRadarChart6.UseRoundSplit = true;
            // 
            // UCTestRadarChart
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucRadarChart6);
            this.Controls.Add(this.ucRadarChart4);
            this.Controls.Add(this.ucRadarChart3);
            this.Controls.Add(this.ucRadarChart5);
            this.Controls.Add(this.ucRadarChart2);
            this.Controls.Add(this.ucRadarChart1);
            this.Name = "UCTestRadarChart";
            this.Size = new System.Drawing.Size(1178, 815);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCRadarChart ucRadarChart1;
        private HZH_Controls.Controls.UCRadarChart ucRadarChart2;
        private HZH_Controls.Controls.UCRadarChart ucRadarChart3;
        private HZH_Controls.Controls.UCRadarChart ucRadarChart4;
        private HZH_Controls.Controls.UCRadarChart ucRadarChart5;
        private HZH_Controls.Controls.UCRadarChart ucRadarChart6;




    }
}
