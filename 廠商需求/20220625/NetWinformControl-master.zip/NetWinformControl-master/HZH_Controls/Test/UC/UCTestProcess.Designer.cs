﻿namespace Test.UC
{
    partial class UCTestProcess
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ucProcessRoll1 = new HZH_Controls.Controls.UCProcessRoll();
            this.ucProcessEllipse3 = new HZH_Controls.Controls.UCProcessEllipse();
            this.ucProcessEllipse4 = new HZH_Controls.Controls.UCProcessEllipse();
            this.ucProcessEllipse1 = new HZH_Controls.Controls.UCProcessEllipse();
            this.ucProcessEllipse2 = new HZH_Controls.Controls.UCProcessEllipse();
            this.ucProcessWave3 = new HZH_Controls.Controls.UCProcessWave();
            this.ucProcessWave2 = new HZH_Controls.Controls.UCProcessWave();
            this.ucProcessWave4 = new HZH_Controls.Controls.UCProcessWave();
            this.ucProcessWave6 = new HZH_Controls.Controls.UCProcessWave();
            this.ucProcessWave5 = new HZH_Controls.Controls.UCProcessWave();
            this.ucProcessWave1 = new HZH_Controls.Controls.UCProcessWave();
            this.ucProcessLineExt2 = new HZH_Controls.Controls.UCProcessLineExt();
            this.ucProcessLineExt1 = new HZH_Controls.Controls.UCProcessLineExt();
            this.ucProcessLine2 = new HZH_Controls.Controls.UCProcessLine();
            this.ucProcessLine1 = new HZH_Controls.Controls.UCProcessLine();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ucProcessRoll1
            // 
            this.ucProcessRoll1.BackColor = System.Drawing.Color.White;
            this.ucProcessRoll1.Location = new System.Drawing.Point(34, 653);
            this.ucProcessRoll1.Name = "ucProcessRoll1";
            this.ucProcessRoll1.Roll = true;
            this.ucProcessRoll1.RollColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.ucProcessRoll1.Size = new System.Drawing.Size(1057, 3);
            this.ucProcessRoll1.SplitTime = 10;
            this.ucProcessRoll1.TabIndex = 28;
            this.ucProcessRoll1.Text = "ucProcessRoll1";
            // 
            // ucProcessEllipse3
            // 
            this.ucProcessEllipse3.BackEllipseColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessEllipse3.CoreEllipseColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            this.ucProcessEllipse3.Font = new System.Drawing.Font("Arial Unicode MS", 23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucProcessEllipse3.ForeColor = System.Drawing.Color.White;
            this.ucProcessEllipse3.IsShowCoreEllipseBorder = false;
            this.ucProcessEllipse3.Location = new System.Drawing.Point(544, 19);
            this.ucProcessEllipse3.MaxValue = 100;
            this.ucProcessEllipse3.Name = "ucProcessEllipse3";
            this.ucProcessEllipse3.ShowType = HZH_Controls.Controls.ShowType.Ring;
            this.ucProcessEllipse3.Size = new System.Drawing.Size(150, 150);
            this.ucProcessEllipse3.TabIndex = 27;
            this.ucProcessEllipse3.Value = 10;
            this.ucProcessEllipse3.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucProcessEllipse3.ValueMargin = 0;
            this.ucProcessEllipse3.ValueType = HZH_Controls.Controls.ValueType.Percent;
            this.ucProcessEllipse3.ValueWidth = 30;
            // 
            // ucProcessEllipse4
            // 
            this.ucProcessEllipse4.BackEllipseColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessEllipse4.CoreEllipseColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessEllipse4.Font = new System.Drawing.Font("Arial Unicode MS", 23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucProcessEllipse4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            this.ucProcessEllipse4.IsShowCoreEllipseBorder = true;
            this.ucProcessEllipse4.Location = new System.Drawing.Point(204, 19);
            this.ucProcessEllipse4.MaxValue = 100;
            this.ucProcessEllipse4.Name = "ucProcessEllipse4";
            this.ucProcessEllipse4.ShowType = HZH_Controls.Controls.ShowType.Ring;
            this.ucProcessEllipse4.Size = new System.Drawing.Size(150, 150);
            this.ucProcessEllipse4.TabIndex = 27;
            this.ucProcessEllipse4.Value = 10;
            this.ucProcessEllipse4.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            this.ucProcessEllipse4.ValueMargin = 5;
            this.ucProcessEllipse4.ValueType = HZH_Controls.Controls.ValueType.Percent;
            this.ucProcessEllipse4.ValueWidth = 30;
            // 
            // ucProcessEllipse1
            // 
            this.ucProcessEllipse1.BackEllipseColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessEllipse1.CoreEllipseColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessEllipse1.Font = new System.Drawing.Font("Arial Unicode MS", 23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ucProcessEllipse1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            this.ucProcessEllipse1.IsShowCoreEllipseBorder = true;
            this.ucProcessEllipse1.Location = new System.Drawing.Point(34, 19);
            this.ucProcessEllipse1.MaxValue = 100;
            this.ucProcessEllipse1.Name = "ucProcessEllipse1";
            this.ucProcessEllipse1.ShowType = HZH_Controls.Controls.ShowType.Ring;
            this.ucProcessEllipse1.Size = new System.Drawing.Size(150, 150);
            this.ucProcessEllipse1.TabIndex = 27;
            this.ucProcessEllipse1.Value = 10;
            this.ucProcessEllipse1.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucProcessEllipse1.ValueMargin = 5;
            this.ucProcessEllipse1.ValueType = HZH_Controls.Controls.ValueType.Percent;
            this.ucProcessEllipse1.ValueWidth = 30;
            // 
            // ucProcessEllipse2
            // 
            this.ucProcessEllipse2.BackEllipseColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessEllipse2.CoreEllipseColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessEllipse2.Font = new System.Drawing.Font("Arial Unicode MS", 20F);
            this.ucProcessEllipse2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            this.ucProcessEllipse2.IsShowCoreEllipseBorder = true;
            this.ucProcessEllipse2.Location = new System.Drawing.Point(374, 19);
            this.ucProcessEllipse2.MaxValue = 100;
            this.ucProcessEllipse2.Name = "ucProcessEllipse2";
            this.ucProcessEllipse2.ShowType = HZH_Controls.Controls.ShowType.Sector;
            this.ucProcessEllipse2.Size = new System.Drawing.Size(150, 150);
            this.ucProcessEllipse2.TabIndex = 26;
            this.ucProcessEllipse2.Value = 20;
            this.ucProcessEllipse2.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucProcessEllipse2.ValueMargin = 5;
            this.ucProcessEllipse2.ValueType = HZH_Controls.Controls.ValueType.Percent;
            this.ucProcessEllipse2.ValueWidth = 30;
            // 
            // ucProcessWave3
            // 
            this.ucProcessWave3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessWave3.ConerRadius = 0;
            this.ucProcessWave3.FillColor = System.Drawing.Color.Empty;
            this.ucProcessWave3.Font = new System.Drawing.Font("微软雅黑", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucProcessWave3.ForeColor = System.Drawing.Color.White;
            this.ucProcessWave3.IsRadius = false;
            this.ucProcessWave3.IsRectangle = false;
            this.ucProcessWave3.IsShowRect = true;
            this.ucProcessWave3.Location = new System.Drawing.Point(228, 342);
            this.ucProcessWave3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucProcessWave3.MaxValue = 100;
            this.ucProcessWave3.Name = "ucProcessWave3";
            this.ucProcessWave3.RectColor = System.Drawing.Color.White;
            this.ucProcessWave3.RectWidth = 4;
            this.ucProcessWave3.Size = new System.Drawing.Size(150, 150);
            this.ucProcessWave3.TabIndex = 24;
            this.ucProcessWave3.Value = 40;
            this.ucProcessWave3.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            // 
            // ucProcessWave2
            // 
            this.ucProcessWave2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessWave2.ConerRadius = 0;
            this.ucProcessWave2.FillColor = System.Drawing.Color.Empty;
            this.ucProcessWave2.Font = new System.Drawing.Font("微软雅黑", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucProcessWave2.ForeColor = System.Drawing.Color.White;
            this.ucProcessWave2.IsRadius = false;
            this.ucProcessWave2.IsRectangle = false;
            this.ucProcessWave2.IsShowRect = true;
            this.ucProcessWave2.Location = new System.Drawing.Point(47, 342);
            this.ucProcessWave2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucProcessWave2.MaxValue = 100;
            this.ucProcessWave2.Name = "ucProcessWave2";
            this.ucProcessWave2.RectColor = System.Drawing.Color.White;
            this.ucProcessWave2.RectWidth = 4;
            this.ucProcessWave2.Size = new System.Drawing.Size(150, 150);
            this.ucProcessWave2.TabIndex = 24;
            this.ucProcessWave2.Value = 40;
            this.ucProcessWave2.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            // 
            // ucProcessWave4
            // 
            this.ucProcessWave4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessWave4.ConerRadius = 0;
            this.ucProcessWave4.FillColor = System.Drawing.Color.Empty;
            this.ucProcessWave4.Font = new System.Drawing.Font("微软雅黑", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucProcessWave4.ForeColor = System.Drawing.Color.White;
            this.ucProcessWave4.IsRadius = false;
            this.ucProcessWave4.IsRectangle = true;
            this.ucProcessWave4.IsShowRect = true;
            this.ucProcessWave4.Location = new System.Drawing.Point(555, 342);
            this.ucProcessWave4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucProcessWave4.MaxValue = 100;
            this.ucProcessWave4.Name = "ucProcessWave4";
            this.ucProcessWave4.RectColor = System.Drawing.Color.White;
            this.ucProcessWave4.RectWidth = 4;
            this.ucProcessWave4.Size = new System.Drawing.Size(108, 150);
            this.ucProcessWave4.TabIndex = 25;
            this.ucProcessWave4.Value = 40;
            this.ucProcessWave4.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            // 
            // ucProcessWave6
            // 
            this.ucProcessWave6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessWave6.ConerRadius = 0;
            this.ucProcessWave6.FillColor = System.Drawing.Color.Empty;
            this.ucProcessWave6.Font = new System.Drawing.Font("微软雅黑", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucProcessWave6.ForeColor = System.Drawing.Color.White;
            this.ucProcessWave6.IsRadius = false;
            this.ucProcessWave6.IsRectangle = true;
            this.ucProcessWave6.IsShowRect = true;
            this.ucProcessWave6.Location = new System.Drawing.Point(378, 542);
            this.ucProcessWave6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucProcessWave6.MaxValue = 100;
            this.ucProcessWave6.Name = "ucProcessWave6";
            this.ucProcessWave6.RectColor = System.Drawing.Color.White;
            this.ucProcessWave6.RectWidth = 4;
            this.ucProcessWave6.Size = new System.Drawing.Size(285, 94);
            this.ucProcessWave6.TabIndex = 25;
            this.ucProcessWave6.Value = 40;
            this.ucProcessWave6.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            // 
            // ucProcessWave5
            // 
            this.ucProcessWave5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessWave5.ConerRadius = 0;
            this.ucProcessWave5.FillColor = System.Drawing.Color.Empty;
            this.ucProcessWave5.Font = new System.Drawing.Font("微软雅黑", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucProcessWave5.ForeColor = System.Drawing.Color.White;
            this.ucProcessWave5.IsRadius = false;
            this.ucProcessWave5.IsRectangle = true;
            this.ucProcessWave5.IsShowRect = true;
            this.ucProcessWave5.Location = new System.Drawing.Point(34, 542);
            this.ucProcessWave5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucProcessWave5.MaxValue = 100;
            this.ucProcessWave5.Name = "ucProcessWave5";
            this.ucProcessWave5.RectColor = System.Drawing.Color.White;
            this.ucProcessWave5.RectWidth = 4;
            this.ucProcessWave5.Size = new System.Drawing.Size(295, 94);
            this.ucProcessWave5.TabIndex = 25;
            this.ucProcessWave5.Value = 40;
            this.ucProcessWave5.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            // 
            // ucProcessWave1
            // 
            this.ucProcessWave1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessWave1.ConerRadius = 0;
            this.ucProcessWave1.FillColor = System.Drawing.Color.Empty;
            this.ucProcessWave1.Font = new System.Drawing.Font("微软雅黑", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ucProcessWave1.ForeColor = System.Drawing.Color.White;
            this.ucProcessWave1.IsRadius = false;
            this.ucProcessWave1.IsRectangle = true;
            this.ucProcessWave1.IsShowRect = true;
            this.ucProcessWave1.Location = new System.Drawing.Point(425, 342);
            this.ucProcessWave1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucProcessWave1.MaxValue = 100;
            this.ucProcessWave1.Name = "ucProcessWave1";
            this.ucProcessWave1.RectColor = System.Drawing.Color.White;
            this.ucProcessWave1.RectWidth = 4;
            this.ucProcessWave1.Size = new System.Drawing.Size(108, 150);
            this.ucProcessWave1.TabIndex = 25;
            this.ucProcessWave1.Value = 40;
            this.ucProcessWave1.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            // 
            // ucProcessLineExt2
            // 
            this.ucProcessLineExt2.BackColor = System.Drawing.Color.Transparent;
            this.ucProcessLineExt2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessLineExt2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            this.ucProcessLineExt2.Location = new System.Drawing.Point(363, 251);
            this.ucProcessLineExt2.MaxValue = 100;
            this.ucProcessLineExt2.Name = "ucProcessLineExt2";
            this.ucProcessLineExt2.Size = new System.Drawing.Size(269, 50);
            this.ucProcessLineExt2.TabIndex = 23;
            this.ucProcessLineExt2.Value = 20;
            this.ucProcessLineExt2.ValueBGColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessLineExt2.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            // 
            // ucProcessLineExt1
            // 
            this.ucProcessLineExt1.BackColor = System.Drawing.Color.Transparent;
            this.ucProcessLineExt1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessLineExt1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucProcessLineExt1.Location = new System.Drawing.Point(70, 251);
            this.ucProcessLineExt1.MaxValue = 100;
            this.ucProcessLineExt1.Name = "ucProcessLineExt1";
            this.ucProcessLineExt1.Size = new System.Drawing.Size(269, 50);
            this.ucProcessLineExt1.TabIndex = 23;
            this.ucProcessLineExt1.Value = 20;
            this.ucProcessLineExt1.ValueBGColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessLineExt1.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            // 
            // ucProcessLine2
            // 
            this.ucProcessLine2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessLine2.Font = new System.Drawing.Font("Arial Unicode MS", 10F);
            this.ucProcessLine2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.ucProcessLine2.Location = new System.Drawing.Point(363, 202);
            this.ucProcessLine2.MaxValue = 150;
            this.ucProcessLine2.Name = "ucProcessLine2";
            this.ucProcessLine2.Size = new System.Drawing.Size(269, 32);
            this.ucProcessLine2.TabIndex = 22;
            this.ucProcessLine2.Text = "ucProcessLine1";
            this.ucProcessLine2.Value = 50;
            this.ucProcessLine2.ValueBGColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessLine2.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(157)))), ((int)(((byte)(144)))));
            this.ucProcessLine2.ValueTextType = HZH_Controls.Controls.ValueTextType.Percent;
            // 
            // ucProcessLine1
            // 
            this.ucProcessLine1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessLine1.Font = new System.Drawing.Font("Arial Unicode MS", 10F);
            this.ucProcessLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.ucProcessLine1.Location = new System.Drawing.Point(70, 202);
            this.ucProcessLine1.MaxValue = 150;
            this.ucProcessLine1.Name = "ucProcessLine1";
            this.ucProcessLine1.Size = new System.Drawing.Size(269, 32);
            this.ucProcessLine1.TabIndex = 22;
            this.ucProcessLine1.Text = "ucProcessLine1";
            this.ucProcessLine1.Value = 50;
            this.ucProcessLine1.ValueBGColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(231)))), ((int)(((byte)(237)))));
            this.ucProcessLine1.ValueColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucProcessLine1.ValueTextType = HZH_Controls.Controls.ValueTextType.Percent;
            // 
            // UCTestProcess
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucProcessRoll1);
            this.Controls.Add(this.ucProcessEllipse3);
            this.Controls.Add(this.ucProcessEllipse4);
            this.Controls.Add(this.ucProcessEllipse1);
            this.Controls.Add(this.ucProcessEllipse2);
            this.Controls.Add(this.ucProcessWave3);
            this.Controls.Add(this.ucProcessWave2);
            this.Controls.Add(this.ucProcessWave4);
            this.Controls.Add(this.ucProcessWave6);
            this.Controls.Add(this.ucProcessWave5);
            this.Controls.Add(this.ucProcessWave1);
            this.Controls.Add(this.ucProcessLineExt2);
            this.Controls.Add(this.ucProcessLineExt1);
            this.Controls.Add(this.ucProcessLine2);
            this.Controls.Add(this.ucProcessLine1);
            this.Name = "UCTestProcess";
            this.Size = new System.Drawing.Size(1125, 696);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCProcessEllipse ucProcessEllipse1;
        private HZH_Controls.Controls.UCProcessEllipse ucProcessEllipse2;
        private HZH_Controls.Controls.UCProcessWave ucProcessWave2;
        private HZH_Controls.Controls.UCProcessWave ucProcessWave1;
        private HZH_Controls.Controls.UCProcessLineExt ucProcessLineExt1;
        private HZH_Controls.Controls.UCProcessLine ucProcessLine1;
        private System.Windows.Forms.Timer timer1;
        private HZH_Controls.Controls.UCProcessEllipse ucProcessEllipse3;
        private HZH_Controls.Controls.UCProcessLine ucProcessLine2;
        private HZH_Controls.Controls.UCProcessLineExt ucProcessLineExt2;
        private HZH_Controls.Controls.UCProcessWave ucProcessWave3;
        private HZH_Controls.Controls.UCProcessWave ucProcessWave4;
        private HZH_Controls.Controls.UCProcessWave ucProcessWave5;
        private HZH_Controls.Controls.UCProcessWave ucProcessWave6;
        private HZH_Controls.Controls.UCProcessEllipse ucProcessEllipse4;
        private HZH_Controls.Controls.UCProcessRoll ucProcessRoll1;
    }
}
