﻿namespace Test.UC
{
    partial class UCTestRollText
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucRollText1 = new HZH_Controls.Controls.UCRollText();
            this.ucRollText2 = new HZH_Controls.Controls.UCRollText();
            this.ucRollText3 = new HZH_Controls.Controls.UCRollText();
            this.ucRollText4 = new HZH_Controls.Controls.UCRollText();
            this.ucRollText5 = new HZH_Controls.Controls.UCRollText();
            this.ucRollText6 = new HZH_Controls.Controls.UCRollText();
            this.SuspendLayout();
            // 
            // ucRollText1
            // 
            this.ucRollText1.BackColor = System.Drawing.Color.White;
            this.ucRollText1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucRollText1.Font = new System.Drawing.Font("微软雅黑", 20F);
            this.ucRollText1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucRollText1.Location = new System.Drawing.Point(0, 0);
            this.ucRollText1.MoveSleepTime = 50;
            this.ucRollText1.Name = "ucRollText1";
            this.ucRollText1.RollStyle = HZH_Controls.Controls.RollStyle.BackAndForth;
            this.ucRollText1.Size = new System.Drawing.Size(861, 55);
            this.ucRollText1.TabIndex = 24;
            this.ucRollText1.Text = "左右滚动文字";
            // 
            // ucRollText2
            // 
            this.ucRollText2.BackColor = System.Drawing.Color.White;
            this.ucRollText2.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucRollText2.Font = new System.Drawing.Font("微软雅黑", 20F);
            this.ucRollText2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucRollText2.Location = new System.Drawing.Point(0, 110);
            this.ucRollText2.MoveSleepTime = 50;
            this.ucRollText2.Name = "ucRollText2";
            this.ucRollText2.RollStyle = HZH_Controls.Controls.RollStyle.LeftToRight;
            this.ucRollText2.Size = new System.Drawing.Size(861, 55);
            this.ucRollText2.TabIndex = 24;
            this.ucRollText2.Text = "从左到右滚动文字";
            // 
            // ucRollText3
            // 
            this.ucRollText3.BackColor = System.Drawing.Color.White;
            this.ucRollText3.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucRollText3.Font = new System.Drawing.Font("微软雅黑", 20F);
            this.ucRollText3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucRollText3.Location = new System.Drawing.Point(0, 220);
            this.ucRollText3.MoveSleepTime = 50;
            this.ucRollText3.Name = "ucRollText3";
            this.ucRollText3.RollStyle = HZH_Controls.Controls.RollStyle.RightToLeft;
            this.ucRollText3.Size = new System.Drawing.Size(861, 55);
            this.ucRollText3.TabIndex = 24;
            this.ucRollText3.Text = "从右到左滚动文字";
            // 
            // ucRollText4
            // 
            this.ucRollText4.BackColor = System.Drawing.Color.Black;
            this.ucRollText4.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucRollText4.Font = new System.Drawing.Font("微软雅黑", 20F);
            this.ucRollText4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucRollText4.Location = new System.Drawing.Point(0, 55);
            this.ucRollText4.MoveSleepTime = 50;
            this.ucRollText4.Name = "ucRollText4";
            this.ucRollText4.RollStyle = HZH_Controls.Controls.RollStyle.BackAndForth;
            this.ucRollText4.Size = new System.Drawing.Size(861, 55);
            this.ucRollText4.TabIndex = 24;
            this.ucRollText4.Text = "左右滚动文字";
            // 
            // ucRollText5
            // 
            this.ucRollText5.BackColor = System.Drawing.Color.Black;
            this.ucRollText5.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucRollText5.Font = new System.Drawing.Font("微软雅黑", 20F);
            this.ucRollText5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucRollText5.Location = new System.Drawing.Point(0, 165);
            this.ucRollText5.MoveSleepTime = 50;
            this.ucRollText5.Name = "ucRollText5";
            this.ucRollText5.RollStyle = HZH_Controls.Controls.RollStyle.LeftToRight;
            this.ucRollText5.Size = new System.Drawing.Size(861, 55);
            this.ucRollText5.TabIndex = 24;
            this.ucRollText5.Text = "从左到右滚动文字";
            // 
            // ucRollText6
            // 
            this.ucRollText6.BackColor = System.Drawing.Color.Black;
            this.ucRollText6.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucRollText6.Font = new System.Drawing.Font("微软雅黑", 20F);
            this.ucRollText6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59)))));
            this.ucRollText6.Location = new System.Drawing.Point(0, 275);
            this.ucRollText6.MoveSleepTime = 50;
            this.ucRollText6.Name = "ucRollText6";
            this.ucRollText6.RollStyle = HZH_Controls.Controls.RollStyle.RightToLeft;
            this.ucRollText6.Size = new System.Drawing.Size(861, 55);
            this.ucRollText6.TabIndex = 24;
            this.ucRollText6.Text = "从右到左滚动文字";
            // 
            // UCTestRollText
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucRollText6);
            this.Controls.Add(this.ucRollText3);
            this.Controls.Add(this.ucRollText5);
            this.Controls.Add(this.ucRollText2);
            this.Controls.Add(this.ucRollText4);
            this.Controls.Add(this.ucRollText1);
            this.Name = "UCTestRollText";
            this.Size = new System.Drawing.Size(861, 454);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCRollText ucRollText1;
        private HZH_Controls.Controls.UCRollText ucRollText2;
        private HZH_Controls.Controls.UCRollText ucRollText3;
        private HZH_Controls.Controls.UCRollText ucRollText4;
        private HZH_Controls.Controls.UCRollText ucRollText5;
        private HZH_Controls.Controls.UCRollText ucRollText6;
    }
}
