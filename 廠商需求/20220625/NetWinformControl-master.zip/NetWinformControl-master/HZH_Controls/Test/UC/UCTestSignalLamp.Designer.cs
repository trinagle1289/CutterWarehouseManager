﻿namespace Test.UC
{
    partial class UCTestSignalLamp
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ucAlarmLamp1 = new HZH_Controls.Controls.UCAlarmLamp();
            this.ucSignalLamp1 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp2 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp3 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp4 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp5 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp6 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp7 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp8 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp9 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp10 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp11 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucSignalLamp12 = new HZH_Controls.Controls.UCSignalLamp();
            this.ucAlarmLamp2 = new HZH_Controls.Controls.UCAlarmLamp();
            this.ucAlarmLamp3 = new HZH_Controls.Controls.UCAlarmLamp();
            this.SuspendLayout();
            // 
            // ucAlarmLamp1
            // 
            this.ucAlarmLamp1.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucAlarmLamp1.Lampstand = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.ucAlarmLamp1.Location = new System.Drawing.Point(27, 377);
            this.ucAlarmLamp1.Name = "ucAlarmLamp1";
            this.ucAlarmLamp1.Size = new System.Drawing.Size(70, 71);
            this.ucAlarmLamp1.TabIndex = 28;
            this.ucAlarmLamp1.TwinkleSpeed = 200;
            // 
            // ucSignalLamp1
            // 
            this.ucSignalLamp1.IsHighlight = true;
            this.ucSignalLamp1.IsShowBorder = true;
            this.ucSignalLamp1.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp1.Location = new System.Drawing.Point(27, 8);
            this.ucSignalLamp1.Name = "ucSignalLamp1";
            this.ucSignalLamp1.Size = new System.Drawing.Size(74, 74);
            this.ucSignalLamp1.TabIndex = 27;
            this.ucSignalLamp1.TwinkleSpeed = 300;
            // 
            // ucSignalLamp2
            // 
            this.ucSignalLamp2.IsHighlight = true;
            this.ucSignalLamp2.IsShowBorder = true;
            this.ucSignalLamp2.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp2.Location = new System.Drawing.Point(128, 17);
            this.ucSignalLamp2.Name = "ucSignalLamp2";
            this.ucSignalLamp2.Size = new System.Drawing.Size(57, 57);
            this.ucSignalLamp2.TabIndex = 27;
            this.ucSignalLamp2.TwinkleSpeed = 300;
            // 
            // ucSignalLamp3
            // 
            this.ucSignalLamp3.IsHighlight = true;
            this.ucSignalLamp3.IsShowBorder = true;
            this.ucSignalLamp3.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp3.Location = new System.Drawing.Point(212, 25);
            this.ucSignalLamp3.Name = "ucSignalLamp3";
            this.ucSignalLamp3.Size = new System.Drawing.Size(41, 41);
            this.ucSignalLamp3.TabIndex = 27;
            this.ucSignalLamp3.TwinkleSpeed = 300;
            // 
            // ucSignalLamp4
            // 
            this.ucSignalLamp4.IsHighlight = true;
            this.ucSignalLamp4.IsShowBorder = false;
            this.ucSignalLamp4.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp4.Location = new System.Drawing.Point(27, 184);
            this.ucSignalLamp4.Name = "ucSignalLamp4";
            this.ucSignalLamp4.Size = new System.Drawing.Size(74, 74);
            this.ucSignalLamp4.TabIndex = 27;
            this.ucSignalLamp4.TwinkleSpeed = 300;
            // 
            // ucSignalLamp5
            // 
            this.ucSignalLamp5.IsHighlight = true;
            this.ucSignalLamp5.IsShowBorder = false;
            this.ucSignalLamp5.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp5.Location = new System.Drawing.Point(128, 193);
            this.ucSignalLamp5.Name = "ucSignalLamp5";
            this.ucSignalLamp5.Size = new System.Drawing.Size(57, 57);
            this.ucSignalLamp5.TabIndex = 27;
            this.ucSignalLamp5.TwinkleSpeed = 300;
            // 
            // ucSignalLamp6
            // 
            this.ucSignalLamp6.IsHighlight = true;
            this.ucSignalLamp6.IsShowBorder = false;
            this.ucSignalLamp6.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp6.Location = new System.Drawing.Point(212, 201);
            this.ucSignalLamp6.Name = "ucSignalLamp6";
            this.ucSignalLamp6.Size = new System.Drawing.Size(41, 41);
            this.ucSignalLamp6.TabIndex = 27;
            this.ucSignalLamp6.TwinkleSpeed = 300;
            // 
            // ucSignalLamp7
            // 
            this.ucSignalLamp7.IsHighlight = false;
            this.ucSignalLamp7.IsShowBorder = false;
            this.ucSignalLamp7.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp7.Location = new System.Drawing.Point(27, 268);
            this.ucSignalLamp7.Name = "ucSignalLamp7";
            this.ucSignalLamp7.Size = new System.Drawing.Size(74, 74);
            this.ucSignalLamp7.TabIndex = 27;
            this.ucSignalLamp7.TwinkleSpeed = 300;
            // 
            // ucSignalLamp8
            // 
            this.ucSignalLamp8.IsHighlight = false;
            this.ucSignalLamp8.IsShowBorder = false;
            this.ucSignalLamp8.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp8.Location = new System.Drawing.Point(128, 277);
            this.ucSignalLamp8.Name = "ucSignalLamp8";
            this.ucSignalLamp8.Size = new System.Drawing.Size(57, 57);
            this.ucSignalLamp8.TabIndex = 27;
            this.ucSignalLamp8.TwinkleSpeed = 300;
            // 
            // ucSignalLamp9
            // 
            this.ucSignalLamp9.IsHighlight = false;
            this.ucSignalLamp9.IsShowBorder = false;
            this.ucSignalLamp9.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp9.Location = new System.Drawing.Point(212, 285);
            this.ucSignalLamp9.Name = "ucSignalLamp9";
            this.ucSignalLamp9.Size = new System.Drawing.Size(41, 41);
            this.ucSignalLamp9.TabIndex = 27;
            this.ucSignalLamp9.TwinkleSpeed = 300;
            // 
            // ucSignalLamp10
            // 
            this.ucSignalLamp10.IsHighlight = false;
            this.ucSignalLamp10.IsShowBorder = true;
            this.ucSignalLamp10.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp10.Location = new System.Drawing.Point(27, 88);
            this.ucSignalLamp10.Name = "ucSignalLamp10";
            this.ucSignalLamp10.Size = new System.Drawing.Size(74, 74);
            this.ucSignalLamp10.TabIndex = 27;
            this.ucSignalLamp10.TwinkleSpeed = 300;
            // 
            // ucSignalLamp11
            // 
            this.ucSignalLamp11.IsHighlight = false;
            this.ucSignalLamp11.IsShowBorder = true;
            this.ucSignalLamp11.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp11.Location = new System.Drawing.Point(128, 97);
            this.ucSignalLamp11.Name = "ucSignalLamp11";
            this.ucSignalLamp11.Size = new System.Drawing.Size(57, 57);
            this.ucSignalLamp11.TabIndex = 27;
            this.ucSignalLamp11.TwinkleSpeed = 300;
            // 
            // ucSignalLamp12
            // 
            this.ucSignalLamp12.IsHighlight = false;
            this.ucSignalLamp12.IsShowBorder = true;
            this.ucSignalLamp12.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucSignalLamp12.Location = new System.Drawing.Point(212, 105);
            this.ucSignalLamp12.Name = "ucSignalLamp12";
            this.ucSignalLamp12.Size = new System.Drawing.Size(41, 41);
            this.ucSignalLamp12.TabIndex = 27;
            this.ucSignalLamp12.TwinkleSpeed = 300;
            // 
            // ucAlarmLamp2
            // 
            this.ucAlarmLamp2.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucAlarmLamp2.Lampstand = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.ucAlarmLamp2.Location = new System.Drawing.Point(128, 394);
            this.ucAlarmLamp2.Name = "ucAlarmLamp2";
            this.ucAlarmLamp2.Size = new System.Drawing.Size(56, 54);
            this.ucAlarmLamp2.TabIndex = 28;
            this.ucAlarmLamp2.TwinkleSpeed = 200;
            // 
            // ucAlarmLamp3
            // 
            this.ucAlarmLamp3.LampColor = new System.Drawing.Color[] {
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(59))))),
        System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))))};
            this.ucAlarmLamp3.Lampstand = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.ucAlarmLamp3.Location = new System.Drawing.Point(205, 408);
            this.ucAlarmLamp3.Name = "ucAlarmLamp3";
            this.ucAlarmLamp3.Size = new System.Drawing.Size(51, 43);
            this.ucAlarmLamp3.TabIndex = 28;
            this.ucAlarmLamp3.TwinkleSpeed = 200;
            // 
            // UCTestSignalLamp
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucAlarmLamp3);
            this.Controls.Add(this.ucAlarmLamp2);
            this.Controls.Add(this.ucAlarmLamp1);
            this.Controls.Add(this.ucSignalLamp9);
            this.Controls.Add(this.ucSignalLamp6);
            this.Controls.Add(this.ucSignalLamp12);
            this.Controls.Add(this.ucSignalLamp3);
            this.Controls.Add(this.ucSignalLamp8);
            this.Controls.Add(this.ucSignalLamp7);
            this.Controls.Add(this.ucSignalLamp5);
            this.Controls.Add(this.ucSignalLamp4);
            this.Controls.Add(this.ucSignalLamp11);
            this.Controls.Add(this.ucSignalLamp2);
            this.Controls.Add(this.ucSignalLamp10);
            this.Controls.Add(this.ucSignalLamp1);
            this.Name = "UCTestSignalLamp";
            this.Size = new System.Drawing.Size(710, 630);
            this.ResumeLayout(false);

        }

        #endregion

        private HZH_Controls.Controls.UCAlarmLamp ucAlarmLamp1;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp1;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp2;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp3;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp4;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp5;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp6;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp7;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp8;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp9;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp10;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp11;
        private HZH_Controls.Controls.UCSignalLamp ucSignalLamp12;
        private HZH_Controls.Controls.UCAlarmLamp ucAlarmLamp2;
        private HZH_Controls.Controls.UCAlarmLamp ucAlarmLamp3;
    }
}
