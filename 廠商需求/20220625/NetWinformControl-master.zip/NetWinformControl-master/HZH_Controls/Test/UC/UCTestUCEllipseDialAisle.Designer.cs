﻿namespace Test.UC
{
    partial class UCTestUCEllipseDialAisle
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {           
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCTestUCEllipseDialAisle));
            this.ucEllipseDialAisle1 = new HZH_Controls.Controls.UCEllipseDialAisle();
            this.ucEllipseDialAisle2 = new HZH_Controls.Controls.UCEllipseDialAisle();
            this.SuspendLayout();
            // 
            // ucEllipseDialAisle1
            // 
            this.ucEllipseDialAisle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ucEllipseDialAisle1.CentreItem = ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.CentreItem")));
            this.ucEllipseDialAisle1.EnabledClick = true;
            this.ucEllipseDialAisle1.Items = new HZH_Controls.Controls.EllipseDialAisleItem[] {
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items1"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items2"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items3"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items4"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items5"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items6"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items7"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items8"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items9"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items10"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle1.Items11")))};
            this.ucEllipseDialAisle1.ItemSize = 30;
            this.ucEllipseDialAisle1.Location = new System.Drawing.Point(57, 49);
            this.ucEllipseDialAisle1.Name = "ucEllipseDialAisle1";
            this.ucEllipseDialAisle1.Size = new System.Drawing.Size(183, 421);
            this.ucEllipseDialAisle1.TabIndex = 0;
            // 
            // ucEllipseDialAisle2
            // 
            this.ucEllipseDialAisle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ucEllipseDialAisle2.CentreItem = ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.CentreItem")));
            this.ucEllipseDialAisle2.EnabledClick = true;
            this.ucEllipseDialAisle2.Items = new HZH_Controls.Controls.EllipseDialAisleItem[] {
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items1"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items2"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items3"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items4"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items5"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items6"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items7"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items8"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items9"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items10"))),
        ((HZH_Controls.Controls.EllipseDialAisleItem)(resources.GetObject("ucEllipseDialAisle2.Items11")))};
            this.ucEllipseDialAisle2.ItemSize = 30;
            this.ucEllipseDialAisle2.Location = new System.Drawing.Point(284, 49);
            this.ucEllipseDialAisle2.Name = "ucEllipseDialAisle2";
            this.ucEllipseDialAisle2.Size = new System.Drawing.Size(373, 150);
            this.ucEllipseDialAisle2.TabIndex = 1;
            // 
            // UCTestUCEllipseDialAisle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ucEllipseDialAisle2);
            this.Controls.Add(this.ucEllipseDialAisle1);
            this.Name = "UCTestUCEllipseDialAisle";
            this.Size = new System.Drawing.Size(698, 592);
            this.ResumeLayout(false);

        }

        #endregion        

        private HZH_Controls.Controls.UCEllipseDialAisle ucEllipseDialAisle1;
        private HZH_Controls.Controls.UCEllipseDialAisle ucEllipseDialAisle2;

    }
}
